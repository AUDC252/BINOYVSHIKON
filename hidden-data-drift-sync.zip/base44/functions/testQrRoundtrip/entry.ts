// End-to-end QR roundtrip test: encode → generate QR data → verify payload integrity
// Since Deno doesn't support canvas for image-based decode, we test:
// 1. Payload sizing (fits within QR limits)
// 2. Data integrity (fragment → serialize → parse → reconstruct)
// 3. Various chunk sizes to find the sweet spot
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);
  const user = await base44.auth.me();
  if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

  // ── Shared utils ──
  function crc32(data) {
    const t = new Int32Array(256);
    for (let i = 0; i < 256; i++) {
      let c = i;
      for (let j = 0; j < 8; j++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1;
      t[i] = c;
    }
    let c = -1;
    for (let i = 0; i < data.length; i++) c = t[(c ^ data[i]) & 0xFF] ^ (c >>> 8);
    return ((c ^ -1) >>> 0).toString(16).padStart(8, '0');
  }

  function toBase64(u8) {
    let bin = '';
    for (let i = 0; i < u8.length; i++) bin += String.fromCharCode(u8[i]);
    return btoa(bin);
  }

  function fromBase64(s) {
    const b = atob(s);
    const a = new Uint8Array(b.length);
    for (let i = 0; i < b.length; i++) a[i] = b.charCodeAt(i);
    return a;
  }

  function genId() {
    const c = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let r = '';
    for (let i = 0; i < 8; i++) r += c[Math.floor(Math.random() * c.length)];
    return r;
  }

  const QR_LIMITS = { L: 2953, M: 2331, Q: 1663, H: 1273 };

  // Test: for a given chunk size + EC level, check payload fits and roundtrips correctly
  function testChunkConfig(name, fileSize, chunkSize, ec) {
    const result = { name, chunkSize, ec, steps: [], success: false };
    const limit = QR_LIMITS[ec];

    // 1. Generate test data
    const data = new Uint8Array(fileSize);
    for (let i = 0; i < data.length; i++) data[i] = (i * 7 + 13) & 0xFF;
    const fileChecksum = crc32(data);

    // 2. Fragment
    const totalChunks = Math.ceil(data.length / chunkSize);
    const tid = genId();
    const payloads = [];
    let maxPayloadBytes = 0;
    let allFit = true;

    for (let idx = 0; idx < totalChunks; idx++) {
      const start = idx * chunkSize;
      const end = Math.min(start + chunkSize, data.length);
      const raw = data.slice(start, end);
      const b64 = toBase64(raw);
      const ck = crc32(raw);

      const payload = idx === 0
        ? { v: 3, t: tid, n: 'testfile.bin', m: 'application/octet-stream', s: data.length, c: totalChunks, i: 0, k: ck, f: fileChecksum, d: b64 }
        : { v: 3, t: tid, c: totalChunks, i: idx, k: ck, f: fileChecksum, d: b64 };

      const jsonStr = JSON.stringify(payload);
      const byteLen = new TextEncoder().encode(jsonStr).length;
      maxPayloadBytes = Math.max(maxPayloadBytes, byteLen);

      if (byteLen > limit) {
        allFit = false;
        result.steps.push(`✗ Chunk ${idx}: ${byteLen}B > ${limit}B limit`);
      }

      payloads.push({ payload, jsonStr, byteLen });
    }

    result.steps.push(`${totalChunks} chunks, max payload=${maxPayloadBytes}B, limit=${limit}B, fits=${allFit}`);
    result.maxPayloadBytes = maxPayloadBytes;
    result.totalChunks = totalChunks;
    result.payloadFits = allFit;
    result.headroom = limit - maxPayloadBytes;

    if (!allFit) {
      result.steps.push('FAIL: Payload exceeds QR capacity');
      return result;
    }

    // 3. Simulate serialize → parse → reconstruct
    const decodedChunks = payloads.map(p => {
      const parsed = JSON.parse(p.jsonStr);
      return parsed;
    });

    decodedChunks.sort((a, b) => a.i - b.i);
    const parts = [];
    let totalBytes = 0;
    for (const chunk of decodedChunks) {
      const bytes = fromBase64(chunk.d);
      parts.push(bytes);
      totalBytes += bytes.length;
    }
    const reconstructed = new Uint8Array(totalBytes);
    let offset = 0;
    for (const p of parts) { reconstructed.set(p, offset); offset += p.length; }

    const rChecksum = crc32(reconstructed);
    const checksumOk = rChecksum === fileChecksum;
    const sizeOk = reconstructed.length === data.length;

    result.steps.push(`Reconstructed ${reconstructed.length}B, checksum=${rChecksum}, match=${checksumOk && sizeOk}`);
    result.success = checksumOk && sizeOk && allFit;

    if (result.success) result.steps.push('✓ PASS');
    else result.steps.push('✗ FAIL');

    return result;
  }

  const results = [];
  // Test the default config: 400B chunks, EC=M
  results.push(testChunkConfig('Default (400B, M) - 100B file', 100, 400, 'M'));
  results.push(testChunkConfig('Default (400B, M) - 500B file', 500, 400, 'M'));
  results.push(testChunkConfig('Default (400B, M) - 2KB file', 2000, 400, 'M'));
  results.push(testChunkConfig('Default (400B, M) - 5KB file', 5000, 400, 'M'));
  results.push(testChunkConfig('Default (400B, M) - 10KB file', 10000, 400, 'M'));

  // Test various chunk sizes with EC=M
  for (const cs of [200, 300, 400, 500, 600, 800, 1000, 1200, 1500]) {
    results.push(testChunkConfig(`ChunkSize=${cs}B, EC=M`, 2000, cs, 'M'));
  }

  // Test various chunk sizes with EC=L (more capacity)
  for (const cs of [400, 800, 1200, 1600, 2000]) {
    results.push(testChunkConfig(`ChunkSize=${cs}B, EC=L`, 2000, cs, 'L'));
  }

  // Find the maximum safe chunk size per EC level
  const safeMaxReport = {};
  for (const ec of ['L', 'M', 'Q', 'H']) {
    let maxSafe = 50;
    for (let cs = 50; cs <= 2500; cs += 25) {
      const r = testChunkConfig(`probe ${ec} ${cs}`, 5000, cs, ec);
      if (r.payloadFits) maxSafe = cs;
      else break;
    }
    safeMaxReport[ec] = { maxSafeChunkBytes: maxSafe };
    // Also report what payload that produces
    const probe = testChunkConfig(`final ${ec}`, 5000, maxSafe, ec);
    safeMaxReport[ec].maxPayloadBytes = probe.maxPayloadBytes;
    safeMaxReport[ec].headroom = probe.headroom;
  }

  const allPass = results.every(r => r.success);

  return Response.json({
    summary: allPass ? '✓ ALL TESTS PASSED' : `✗ SOME TESTS FAILED`,
    safeMaxChunkSizes: safeMaxReport,
    defaultConfig: { chunkSize: 400, errorCorrection: 'M', note: 'Lower density = easier to scan' },
    results: results.map(r => ({
      name: r.name,
      success: r.success,
      totalChunks: r.totalChunks,
      maxPayloadBytes: r.maxPayloadBytes,
      headroom: r.headroom,
      payloadFits: r.payloadFits,
    })),
  });
});