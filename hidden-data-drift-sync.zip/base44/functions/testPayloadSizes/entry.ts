import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

function toBase64(u8) {
  let bin = '';
  for (let i = 0; i < u8.length; i++) bin += String.fromCharCode(u8[i]);
  return btoa(bin);
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const limits = { L: 2953, M: 2331, Q: 1663, H: 1273 };
    const results = [];

    // Test different chunk sizes and see actual payload sizes
    for (const chunkSize of [400, 600, 800, 1000, 1200, 1500, 2000]) {
      const testData = new Uint8Array(chunkSize);
      for (let i = 0; i < testData.length; i++) testData[i] = i % 256;
      const base64 = toBase64(testData);

      // Chunk 0 with encryption (worst case)
      const chunk0enc = JSON.stringify({
        v: 3, t: 'ABCDEFGH', n: 'my_important_document.pdf',
        m: 'application/pdf', s: 50000, c: 50, i: 0,
        k: 'a1b2c3d4', f: 'e5f6a7b8', d: base64, e: 1
      });

      // Chunk 0 without encryption
      const chunk0plain = JSON.stringify({
        v: 3, t: 'ABCDEFGH', n: 'my_important_document.pdf',
        m: 'application/pdf', s: 50000, c: 50, i: 0,
        k: 'a1b2c3d4', f: 'e5f6a7b8', d: base64
      });

      // Slim chunk (non-0)
      const chunkN = JSON.stringify({
        v: 3, t: 'ABCDEFGH', c: 50, i: 25,
        k: 'a1b2c3d4', f: 'e5f6a7b8', d: base64, e: 1
      });

      const enc = new TextEncoder();
      results.push({
        rawChunkSize: chunkSize,
        base64Size: base64.length,
        chunk0_encrypted_bytes: enc.encode(chunk0enc).length,
        chunk0_plain_bytes: enc.encode(chunk0plain).length,
        chunkN_bytes: enc.encode(chunkN).length,
        fitsInQR_L: enc.encode(chunk0enc).length <= limits.L,
        fitsInQR_M: enc.encode(chunk0enc).length <= limits.M,
        headroom_L: limits.L - enc.encode(chunk0enc).length,
        headroom_M: limits.M - enc.encode(chunk0enc).length,
      });
    }

    // Also test with the auto-tuned max chunk size
    const dummyEnvelope = JSON.stringify({
      v: 3, t: 'XXXXXXXX', n: 'my_important_document.pdf',
      m: 'application/octet-stream', s: 999999999, c: 9999, i: 0,
      k: 'xxxxxxxx', f: 'xxxxxxxx', d: '', e: 1
    });
    const overhead = new TextEncoder().encode(dummyEnvelope).length + 20;
    const maxRawL = Math.max(50, Math.floor((limits.L - overhead) * 3 / 4));
    const maxRawM = Math.max(50, Math.floor((limits.M - overhead) * 3 / 4));

    return Response.json({
      qrLimits: limits,
      overhead,
      autoTunedMax_L: maxRawL,
      autoTunedMax_M: maxRawM,
      payloadSizes: results,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});