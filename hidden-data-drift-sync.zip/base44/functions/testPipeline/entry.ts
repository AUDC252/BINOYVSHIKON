import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

// ── Inline crypto + chunking logic (same as frontend) ──

// CRC32
const crcTable = (() => {
  const t = new Int32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let j = 0; j < 8; j++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1;
    t[i] = c;
  }
  return t;
})();

function crc32(data) {
  let c = -1;
  for (let i = 0; i < data.length; i++) c = crcTable[(c ^ data[i]) & 0xFF] ^ (c >>> 8);
  return ((c ^ -1) >>> 0).toString(16).padStart(8, '0');
}

// Xoshiro128**
function xoshiro128ss(s0, s1, s2, s3) {
  return function () {
    const r = Math.imul(s1 * 5, 9);
    const q = ((r << 7) | (r >>> 25)) * 9;
    const t = s1 << 9;
    s2 ^= s0; s3 ^= s1; s1 ^= s2; s0 ^= s3; s2 ^= t;
    s3 = ((s3 << 11) | (s3 >>> 21));
    s0 >>>= 0; s1 >>>= 0; s2 >>>= 0; s3 >>>= 0;
    return (q >>> 0) / 4294967296;
  };
}

function passwordToSeeds(password, salt) {
  const seeds = [2166136261, 2166136261 ^ 0x811c9dc5, 2166136261 ^ 0x01000193, 2166136261 ^ 0xDEADBEEF];
  for (let x = 0; x < 4; x++) {
    for (let i = 0; i < password.length; i++) {
      seeds[x] ^= password.charCodeAt(i) + x * 31 + (salt || 0);
      seeds[x] = Math.imul(seeds[x], 16777619);
      seeds[x] >>>= 0;
    }
    seeds[x] = (seeds[x] ^ (seeds[x] >>> 16)) >>> 0;
    seeds[x] = (seeds[x] | 1) >>> 0;
  }
  return seeds;
}

function xorCrypt(data, password, chunkIndex) {
  const salt = (chunkIndex * 2654435761 + 0xA5A5A5A5) >>> 0;
  const se = passwordToSeeds(password, salt);
  const rng = xoshiro128ss(se[0], se[1], se[2], se[3]);
  for (let i = 0; i < 20; i++) rng();
  const result = new Uint8Array(data.length);
  for (let i = 0; i < data.length; i++) result[i] = data[i] ^ Math.floor(rng() * 256);
  return result;
}

function passwordToSeed(password) {
  let h = 2166136261;
  for (let i = 0; i < password.length; i++) {
    h ^= password.charCodeAt(i);
    h = Math.imul(h, 16777619);
    h >>>= 0;
  }
  return h;
}

function poisonChecksum(hex, password) {
  const se = passwordToSeeds(password, 0xC0FFEE);
  const rng = xoshiro128ss(se[0], se[1], se[2], se[3]);
  let result = '';
  for (let i = 0; i < hex.length; i++) {
    const b = Math.floor(rng() * 16);
    result += ((parseInt(hex[i], 16) ^ b) & 0xf).toString(16);
  }
  return result;
}

function depoisonChecksum(hex, password) {
  return poisonChecksum(hex, password); // XOR is symmetric
}

function toBase64(u8) {
  // Use a method that works in Deno
  let bin = '';
  for (let i = 0; i < u8.length; i++) bin += String.fromCharCode(u8[i]);
  return btoa(bin);
}

function fromBase64(s) {
  const bin = atob(s);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
}

function generateTransferId() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let id = '';
  const arr = new Uint8Array(8);
  crypto.getRandomValues(arr);
  for (let i = 0; i < 8; i++) id += chars[arr[i] % chars.length];
  return id;
}

function generateShufflePermutation(length, password) {
  const seed = passwordToSeed(password);
  const idx = Array.from({ length }, (_, i) => i);
  const rng = xoshiro128ss(
    (seed | 1) >>> 0,
    ((seed * 2654435761) >>> 0 | 1) >>> 0,
    ((seed * 2246822519) >>> 0 | 1) >>> 0,
    ((seed * 3266489917) >>> 0 | 1) >>> 0
  );
  for (let i = 0; i < 10; i++) rng();
  for (let i = idx.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [idx[i], idx[j]] = [idx[j], idx[i]];
  }
  return idx;
}

function shuffleChunks(chunks, password) {
  const permutation = generateShufflePermutation(chunks.length, password);
  const shuffled = new Array(chunks.length);
  for (let i = 0; i < chunks.length; i++) {
    shuffled[i] = chunks[permutation[i]];
  }
  return { shuffled, permutation };
}

// ── Parse chunk (same logic as frontend parseChunkPayload) ──
function parseChunkPayload(payloadString) {
  const p = JSON.parse(payloadString);
  return {
    v: p.v ?? 2,
    tid: p.t ?? p.tid,
    fn: p.n ?? p.fn,
    mt: p.m ?? p.mt,
    fs: p.s ?? p.fs,
    tc: p.c ?? p.tc,
    ci: p.i ?? p.ci,
    cc: p.k ?? p.cc,
    fc: p.f ?? p.fc,
    d: p.d,
    encrypted: !!(p.e || p.encrypted),
  };
}

// ── Full encode pipeline ──
function encodeFile(fileBytes, fileName, mimeType, password) {
  const encrypted = !!password;
  const uint8 = new Uint8Array(fileBytes);
  const fileChecksum = crc32(uint8);
  const fileSize = uint8.byteLength;
  const chunkSize = 800; // match default
  const totalChunks = Math.ceil(fileSize / chunkSize);
  const transferId = generateTransferId();
  const visibleFileChecksum = encrypted ? poisonChecksum(fileChecksum, password) : fileChecksum;

  const rawChunks = [];
  for (let idx = 0; idx < totalChunks; idx++) {
    const start = idx * chunkSize;
    const end = Math.min(start + chunkSize, fileSize);
    const rawSlice = uint8.slice(start, end);
    const rawChecksum = crc32(rawSlice);

    let chunkData = rawSlice;
    if (encrypted) {
      chunkData = xorCrypt(rawSlice, password, idx);
    }

    const base64Data = toBase64(chunkData);
    const visibleChecksum = encrypted ? poisonChecksum(rawChecksum, password) : rawChecksum;

    const payload = idx === 0
      ? { v: 3, t: transferId, n: fileName, m: mimeType, s: fileSize, c: totalChunks, i: 0, k: visibleChecksum, f: visibleFileChecksum, d: base64Data }
      : { v: 3, t: transferId, c: totalChunks, i: idx, k: visibleChecksum, f: visibleFileChecksum, d: base64Data };

    if (encrypted) payload.e = 1;
    rawChunks.push(payload);
  }

  let finalChunks = rawChunks;
  if (encrypted && totalChunks > 1) {
    const { shuffled } = shuffleChunks(rawChunks, password);
    finalChunks = shuffled;
  }

  return {
    transferId, fileName, fileChecksum, fileSize, totalChunks, chunkSize,
    chunks: finalChunks,
    encrypted,
  };
}

// ── Full decode pipeline ──
function decodeAndReconstruct(encodedChunks, password) {
  // Step 1: Parse all chunk payloads (simulating QR scan)
  const parsed = encodedChunks.map(chunk => {
    const jsonStr = JSON.stringify(chunk);
    return parseChunkPayload(jsonStr);
  });

  // Step 2: Analyze collection
  const ref = parsed[0];
  const transferId = ref.tid;
  const totalChunks = ref.tc;
  const collected = new Map();

  for (const chunk of parsed) {
    if (chunk.tid !== transferId) continue;
    if (!collected.has(chunk.ci)) {
      collected.set(chunk.ci, chunk);
    }
  }

  const missingIndices = [];
  for (let i = 0; i < totalChunks; i++) {
    if (!collected.has(i)) missingIndices.push(i);
  }

  const complete = missingIndices.length === 0 && collected.size === totalChunks;
  const chunk0 = collected.get(0);
  const metaChunk = chunk0 || parsed.find(c => c.fn) || ref;
  const encrypted = parsed.some(c => c.encrypted);
  const fileChecksum = metaChunk.fc || ref.fc;

  if (!complete) {
    return {
      success: false,
      error: `Missing ${missingIndices.length} chunks: [${missingIndices.join(', ')}]`,
      totalChunks,
      collected: collected.size,
      missingIndices,
    };
  }

  // Step 3: Reconstruct
  const parts = [];
  let totalBytes = 0;
  for (let i = 0; i < totalChunks; i++) {
    const chunk = collected.get(i);
    let decoded = fromBase64(chunk.d);
    if (encrypted && password) {
      decoded = xorCrypt(decoded, password, i);
    }
    parts.push(decoded);
    totalBytes += decoded.byteLength;
  }

  const reconstructed = new Uint8Array(totalBytes);
  let offset = 0;
  for (const part of parts) {
    reconstructed.set(part, offset);
    offset += part.byteLength;
  }

  // Step 4: Verify checksum
  const actualChecksum = crc32(reconstructed);
  let expectedChecksum = fileChecksum;
  if (encrypted && password) {
    expectedChecksum = depoisonChecksum(fileChecksum, password);
  }

  const checksumMatch = actualChecksum === expectedChecksum;

  return {
    success: checksumMatch,
    actualChecksum,
    expectedChecksum,
    fileSize: reconstructed.byteLength,
    totalChunks,
    collected: collected.size,
    encrypted,
    checksumMatch,
    error: checksumMatch ? null : 'Checksum mismatch',
  };
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const results = [];

    // Test 1: Small file, no encryption
    {
      const testData = new TextEncoder().encode('Hello, World! This is a test file for QR fragment encoding.');
      const encoded = encodeFile(testData.buffer, 'test.txt', 'text/plain', null);
      const result = decodeAndReconstruct(encoded.chunks, null);
      results.push({
        test: 'Small file, no encryption',
        fileSize: testData.length,
        totalChunks: encoded.totalChunks,
        ...result,
      });
    }

    // Test 2: Small file, with encryption
    {
      const testData = new TextEncoder().encode('Hello, World! This is an encrypted test file.');
      const password = 'mySecretPassword123!';
      const encoded = encodeFile(testData.buffer, 'encrypted.txt', 'text/plain', password);
      const result = decodeAndReconstruct(encoded.chunks, password);
      results.push({
        test: 'Small file, with encryption',
        fileSize: testData.length,
        totalChunks: encoded.totalChunks,
        password,
        ...result,
      });
    }

    // Test 3: Multi-chunk file, no encryption
    {
      const testData = new Uint8Array(5000);
      for (let i = 0; i < testData.length; i++) testData[i] = i % 256;
      const encoded = encodeFile(testData.buffer, 'multi.bin', 'application/octet-stream', null);
      const result = decodeAndReconstruct(encoded.chunks, null);
      results.push({
        test: 'Multi-chunk (5KB), no encryption',
        fileSize: testData.length,
        totalChunks: encoded.totalChunks,
        ...result,
      });
    }

    // Test 4: Multi-chunk file, with encryption (this is the critical test)
    {
      const testData = new Uint8Array(5000);
      for (let i = 0; i < testData.length; i++) testData[i] = i % 256;
      const password = 'strongPassword!@#$%^&*()';
      const encoded = encodeFile(testData.buffer, 'encrypted_multi.bin', 'application/octet-stream', password);
      const result = decodeAndReconstruct(encoded.chunks, password);
      results.push({
        test: 'Multi-chunk (5KB), with encryption',
        fileSize: testData.length,
        totalChunks: encoded.totalChunks,
        password,
        shuffledOrder: encoded.chunks.map(c => c.i),
        ...result,
      });
    }

    // Test 5: Multi-chunk encrypted with wrong password (should fail)
    {
      const testData = new Uint8Array(3000);
      for (let i = 0; i < testData.length; i++) testData[i] = (i * 7) % 256;
      const password = 'correctPassword';
      const encoded = encodeFile(testData.buffer, 'wrong_pw.bin', 'application/octet-stream', password);
      const result = decodeAndReconstruct(encoded.chunks, 'wrongPassword');
      results.push({
        test: 'Multi-chunk encrypted, WRONG password (should fail)',
        fileSize: testData.length,
        totalChunks: encoded.totalChunks,
        expectedToFail: true,
        ...result,
      });
    }

    // Test 6: Larger file with encryption (20KB)
    {
      const testData = new Uint8Array(20000);
      for (let i = 0; i < testData.length; i++) testData[i] = (i * 13 + 37) % 256;
      const password = 'bigFilePassword';
      const encoded = encodeFile(testData.buffer, 'large_encrypted.dat', 'application/octet-stream', password);
      const result = decodeAndReconstruct(encoded.chunks, password);
      results.push({
        test: 'Large file (20KB), with encryption',
        fileSize: testData.length,
        totalChunks: encoded.totalChunks,
        password,
        ...result,
      });
    }

    // Test 7: Verify poison/depoison symmetry
    {
      const checksum = 'a1b2c3d4';
      const password = 'testPw';
      const poisoned = poisonChecksum(checksum, password);
      const depoisoned = depoisonChecksum(poisoned, password);
      results.push({
        test: 'Poison/Depoison symmetry',
        original: checksum,
        poisoned,
        depoisoned,
        success: checksum === depoisoned,
      });
    }

    // Test 8: Verify XOR encrypt/decrypt symmetry
    {
      const original = new Uint8Array([1, 2, 3, 4, 5, 100, 200, 255, 0, 128]);
      const password = 'xorTest';
      const encrypted = xorCrypt(original, password, 0);
      const decrypted = xorCrypt(encrypted, password, 0);
      const match = original.every((v, i) => v === decrypted[i]);
      results.push({
        test: 'XOR encrypt/decrypt symmetry',
        original: Array.from(original),
        encrypted: Array.from(encrypted),
        decrypted: Array.from(decrypted),
        success: match,
      });
    }

    // Test 9: Verify XOR with different chunk indices gives different results
    {
      const data = new Uint8Array([1, 2, 3, 4, 5]);
      const password = 'indexTest';
      const enc0 = xorCrypt(data, password, 0);
      const enc1 = xorCrypt(data, password, 1);
      const different = !enc0.every((v, i) => v === enc1[i]);
      results.push({
        test: 'XOR different per chunk index',
        chunk0: Array.from(enc0),
        chunk1: Array.from(enc1),
        success: different,
      });
    }

    const allPassed = results.every(r => 
      r.expectedToFail ? !r.success : r.success
    );

    return Response.json({
      allPassed,
      totalTests: results.length,
      results,
    });
  } catch (error) {
    return Response.json({ error: error.message, stack: error.stack }, { status: 500 });
  }
});