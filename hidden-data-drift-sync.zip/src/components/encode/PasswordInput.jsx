import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Lock, Eye, EyeOff, ShieldCheck, Shuffle, FileWarning } from 'lucide-react';

export default function PasswordInput({ password, onChange }) {
  const [enabled, setEnabled] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const handleToggle = (checked) => {
    setEnabled(checked);
    if (!checked) onChange('');
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <Label className="text-xs sm:text-sm font-medium flex items-center gap-1.5">
          <Lock className="w-3.5 h-3.5" /> Encryption
        </Label>
        <Switch checked={enabled} onCheckedChange={handleToggle} />
      </div>

      {enabled && (
        <div className="space-y-2.5 sm:space-y-3">
          <div className="relative">
            <Input
              type={showPassword ? 'text' : 'password'}
              placeholder="Enter password"
              value={password}
              onChange={(e) => onChange(e.target.value)}
              className="pr-10 font-mono text-sm"
            />
            <button type="button" onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
          <div className="space-y-1.5 text-[10px] sm:text-xs text-muted-foreground">
            <div className="flex items-start gap-1.5">
              <ShieldCheck className="w-3 h-3 sm:w-3.5 sm:h-3.5 mt-0.5 shrink-0 text-accent" />
              <span><strong className="text-foreground">XOR Cipher:</strong> Unique key per chunk</span>
            </div>
            <div className="flex items-start gap-1.5">
              <Shuffle className="w-3 h-3 sm:w-3.5 sm:h-3.5 mt-0.5 shrink-0 text-primary" />
              <span><strong className="text-foreground">Chunk Shuffle:</strong> Order randomized</span>
            </div>
            <div className="flex items-start gap-1.5">
              <FileWarning className="w-3 h-3 sm:w-3.5 sm:h-3.5 mt-0.5 shrink-0 text-destructive" />
              <span><strong className="text-foreground">Checksum Poison:</strong> Hashes encrypted</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}