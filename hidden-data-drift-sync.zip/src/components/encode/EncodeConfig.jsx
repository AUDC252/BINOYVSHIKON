import React from 'react';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Settings2 } from 'lucide-react';
import { MIN_CHUNK_DATA_SIZE, MAX_CHUNK_DATA_SIZE, DEFAULT_CHUNK_DATA_SIZE, estimateChunkCount } from '@/lib/qr-transfer';

export default function EncodeConfig({ config, onChange, fileSize }) {
  const chunkCount = fileSize ? estimateChunkCount(fileSize, config.chunkDataSize) : 0;

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-semibold flex items-center gap-2">
          <Settings2 className="w-4 h-4" />
          Configuration
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-5">
        <div>
          <div className="flex items-center justify-between mb-2">
            <Label className="text-xs">Chunk Size (bytes of file data per QR)</Label>
            <span className="text-xs font-mono text-muted-foreground">{config.chunkDataSize} B</span>
          </div>
          <Slider
            value={[config.chunkDataSize]}
            onValueChange={([val]) => onChange({ ...config, chunkDataSize: val })}
            min={MIN_CHUNK_DATA_SIZE}
            max={MAX_CHUNK_DATA_SIZE}
            step={50}
          />
          <div className="flex justify-between text-xs text-muted-foreground mt-1">
            <span>{MIN_CHUNK_DATA_SIZE} B</span>
            <span>{MAX_CHUNK_DATA_SIZE} B</span>
          </div>
        </div>

        <div>
          <Label className="text-xs mb-2 block">Error Correction Level</Label>
          <Select
            value={config.errorCorrection}
            onValueChange={(val) => onChange({ ...config, errorCorrection: val })}
          >
            <SelectTrigger className="h-9 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="L">Low (~7% recovery)</SelectItem>
              <SelectItem value="M">Medium (~15% recovery)</SelectItem>
              <SelectItem value="Q">Quartile (~25% recovery)</SelectItem>
              <SelectItem value="H">High (~30% recovery)</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {fileSize > 0 && (
          <div className="rounded-md bg-muted p-3">
            <p className="text-xs text-muted-foreground">
              Estimated QR codes: <span className="font-mono font-semibold text-foreground">{chunkCount}</span>
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}