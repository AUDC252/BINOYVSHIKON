import React, { useCallback, useRef } from 'react';
import { Upload, File, X, FileText, Image, Archive, Film } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { formatBytes } from '@/lib/qr-engine';

const FILE_ICONS = {
  'application/pdf': FileText,
  'text/plain': FileText,
  'image/png': Image,
  'image/jpeg': Image,
  'image/jpg': Image,
  'application/zip': Archive,
  'video/mp4': Film,
};

export default function FileUploader({ file, onFileSelect, onClear }) {
  const inputRef = useRef(null);

  const handleDrop = useCallback((e) => {
    e.preventDefault();
    const dropped = e.dataTransfer.files[0];
    if (dropped) onFileSelect(dropped);
  }, [onFileSelect]);

  const handleDragOver = useCallback((e) => { e.preventDefault(); }, []);

  if (file) {
    const IconComp = FILE_ICONS[file.type] || File;
    return (
      <div className="rounded-lg border-2 border-primary/20 bg-primary/5 p-3 sm:p-5">
        <div className="flex items-start gap-3 sm:gap-4">
          <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
            <IconComp className="w-5 h-5 sm:w-6 sm:h-6 text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-semibold text-sm truncate">{file.name}</p>
            <div className="flex flex-wrap gap-x-3 gap-y-0.5 mt-1 text-xs text-muted-foreground">
              <span>{formatBytes(file.size)}</span>
              <span className="font-mono truncate">{file.type || 'unknown'}</span>
            </div>
          </div>
          <Button variant="ghost" size="icon" className="shrink-0 h-8 w-8" onClick={onClear}>
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div
      onDrop={handleDrop}
      onDragOver={handleDragOver}
      onClick={() => inputRef.current?.click()}
      className="rounded-lg border-2 border-dashed border-border hover:border-primary/40 transition-colors cursor-pointer p-6 sm:p-10 text-center"
    >
      <input ref={inputRef} type="file" className="hidden" onChange={(e) => e.target.files?.[0] && onFileSelect(e.target.files[0])} />
      <Upload className="w-8 h-8 sm:w-10 sm:h-10 text-muted-foreground mx-auto mb-2 sm:mb-3" />
      <p className="font-medium text-sm">Drop a file here or tap to browse</p>
      <p className="text-xs text-muted-foreground mt-1">Any file type supported</p>
    </div>
  );
}