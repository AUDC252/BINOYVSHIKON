import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Info, Copy, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { formatBytes } from '@/lib/qr-engine';

export default function TransferSummary({ session }) {
  const [copied, setCopied] = React.useState(false);
  if (!session) return null;

  const { id: transferId, fileName, mimeType, fileSize, totalChunks, fileChecksum, chunkSize, timestamp, createdAt } = session;

  const copyId = () => {
    navigator.clipboard.writeText(transferId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Card>
      <CardHeader className="pb-2 sm:pb-3 px-3 sm:px-6 pt-3 sm:pt-6">
        <CardTitle className="text-sm font-semibold flex items-center gap-2">
          <Info className="w-4 h-4" /> Transfer Summary
        </CardTitle>
      </CardHeader>
      <CardContent className="px-3 sm:px-6 pb-3 sm:pb-6">
        <div className="grid grid-cols-2 gap-x-4 sm:gap-x-6 gap-y-2.5 sm:gap-y-3 text-xs">
          <div>
            <p className="text-muted-foreground">Transfer ID</p>
            <div className="flex items-center gap-1.5 mt-0.5">
              <code className="font-mono text-[10px] sm:text-xs bg-muted px-1.5 py-0.5 rounded truncate">{transferId}</code>
              <Button variant="ghost" size="icon" className="h-5 w-5 shrink-0" onClick={copyId}>
                {copied ? <Check className="w-3 h-3 text-accent" /> : <Copy className="w-3 h-3" />}
              </Button>
            </div>
          </div>
          <div>
            <p className="text-muted-foreground">File Name</p>
            <p className="font-medium mt-0.5 truncate">{fileName}</p>
          </div>
          <div>
            <p className="text-muted-foreground">MIME Type</p>
            <Badge variant="secondary" className="mt-0.5 text-[10px] sm:text-xs">{mimeType}</Badge>
          </div>
          <div>
            <p className="text-muted-foreground">File Size</p>
            <p className="font-medium mt-0.5">{formatBytes(fileSize)}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Total Chunks</p>
            <p className="font-mono font-medium mt-0.5">{totalChunks}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Chunk Size</p>
            <p className="font-mono font-medium mt-0.5">{formatBytes(chunkSize)}</p>
          </div>
          <div className="col-span-2">
            <p className="text-muted-foreground">File Checksum</p>
            <code className="font-mono text-[10px] sm:text-xs bg-muted px-1.5 py-0.5 rounded mt-0.5 inline-block break-all">{fileChecksum}</code>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}