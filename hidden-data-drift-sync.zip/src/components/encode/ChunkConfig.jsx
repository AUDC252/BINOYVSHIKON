import React from 'react';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { calculateMaxChunkBytes, estimatePayloadSize, estimateChunk0PayloadSize, getMaxPayloadBytes, formatBytes } from '@/lib/qr-engine';
import { AlertTriangle, CheckCircle2, Info } from 'lucide-react';

export default function ChunkConfig({ config, onChange, fileName, encrypted }) {
  const { chunkSize, errorCorrection } = config;
  const maxChunkBytes = calculateMaxChunkBytes(fileName, errorCorrection, !!encrypted);
  // Recommended max for reliable scanning (lower density QR codes)
  const recommendedMax = Math.min(Math.floor(maxChunkBytes * 0.5), maxChunkBytes);
  const payloadEst = Math.max(
    estimatePayloadSize(chunkSize),
    estimateChunk0PayloadSize(chunkSize, fileName)
  );
  const qrLimit = getMaxPayloadBytes(errorCorrection);
  const isSafe = chunkSize <= maxChunkBytes;
  const isRecommended = chunkSize <= recommendedMax;
  const sliderMax = Math.min(2000, maxChunkBytes + 200);

  return (
    <div className="space-y-4 sm:space-y-5">
      <div>
        <div className="flex items-center justify-between mb-2">
          <Label className="text-xs sm:text-sm font-medium">Chunk Size</Label>
          <div className="flex items-center gap-1.5 sm:gap-2">
            <span className="text-[10px] sm:text-xs font-mono bg-muted px-1.5 sm:px-2 py-0.5 rounded">
              {formatBytes(chunkSize)}
            </span>
            {isSafe ? (
              <CheckCircle2 className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-accent" />
            ) : (
              <AlertTriangle className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-destructive" />
            )}
          </div>
        </div>
        <Slider
          value={[chunkSize]}
          onValueChange={([v]) => onChange({ ...config, chunkSize: v })}
          min={50}
          max={sliderMax}
          step={25}
          className="w-full"
        />
        <div className="flex justify-between text-[10px] sm:text-xs text-muted-foreground mt-1">
          <span>50 B</span>
          <span className="text-accent font-mono">max: {formatBytes(maxChunkBytes)}</span>
          <span>{formatBytes(sliderMax)}</span>
        </div>
      </div>

      <div>
        <Label className="text-xs sm:text-sm font-medium mb-2 block">Error Correction</Label>
        <Select
          value={errorCorrection}
          onValueChange={(v) => {
            const newMax = calculateMaxChunkBytes(fileName, v, !!encrypted);
            const newChunkSize = Math.min(chunkSize, newMax);
            onChange({ ...config, errorCorrection: v, chunkSize: newChunkSize });
          }}
        >
          <SelectTrigger className="w-full text-xs sm:text-sm">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="L">Low (7%) — Max capacity</SelectItem>
            <SelectItem value="M">Medium (15%)</SelectItem>
            <SelectItem value="Q">Quartile (25%)</SelectItem>
            <SelectItem value="H">High (30%) — Best recovery</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className={`rounded-md p-2.5 sm:p-3 text-[10px] sm:text-xs space-y-1 ${!isSafe ? 'bg-destructive/5 border border-destructive/20' : !isRecommended ? 'bg-yellow-500/5 border border-yellow-500/20' : 'bg-accent/5 border border-accent/20'}`}>
        <div className="flex items-center gap-1.5">
          <Info className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-muted-foreground shrink-0" />
          <span>Est. payload: <strong className="font-mono">{payloadEst}</strong> / {qrLimit} bytes</span>
        </div>
        {!isSafe ? (
          <p className="ml-4 sm:ml-5 text-destructive">Will be clamped to {formatBytes(maxChunkBytes)}</p>
        ) : !isRecommended ? (
          <p className="ml-4 sm:ml-5 text-yellow-600">⚠ High density — scanning may be unreliable</p>
        ) : (
          <p className="ml-4 sm:ml-5 text-accent">✓ Recommended range — reliable scanning</p>
        )}
      </div>
    </div>
  );
}