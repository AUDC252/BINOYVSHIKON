import React, { useState } from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import { QrCode, Upload, ScanLine, Home, History, Menu, X, Palette, Camera, FileText, Shield } from 'lucide-react';
import { cn } from '@/lib/utils';

const navItems = [
  { path: '/', label: 'Home', icon: Home },
  { path: '/encode', label: 'Encode', icon: Upload },
  { path: '/decode', label: 'Decode', icon: ScanLine },
  { path: '/transfers', label: 'Transfers', icon: History },
  { path: '/print-encode', label: 'Print', icon: Palette },
  { path: '/print-decode', label: 'Scan', icon: Camera },
  { path: '/encryption-demo', label: 'Crypto', icon: Shield },
  { path: '/landing', label: 'About', icon: FileText },
];

export default function AppShell() {
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      {/* Top nav */}
      <header className="sticky top-0 z-50 border-b border-border/60 bg-card/90 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 flex items-center h-12 sm:h-14 gap-3 sm:gap-6">
          <Link to="/" className="flex items-center gap-2 shrink-0 group">
            <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-primary/10 border border-primary/30 flex items-center justify-center glow-cyan">
              <QrCode className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-primary" />
            </div>
            <span className="font-display text-[10px] sm:text-xs font-bold tracking-widest uppercase text-primary hidden sm:inline glow-text-cyan">
              QR Fragment
            </span>
          </Link>

          <div className="h-6 w-px bg-border/60 hidden sm:block" />

          {/* Desktop nav */}
          <nav className="hidden sm:flex items-center gap-1 ml-1">
            {navItems.map(({ path, label, icon: Icon }) => {
              const active = location.pathname === path || 
                (path !== '/' && location.pathname.startsWith(path));
              return (
                <Link
                  key={path}
                  to={path}
                  className={cn(
                    'flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-mono font-medium tracking-wide uppercase transition-all',
                    active
                      ? 'bg-primary/10 text-primary border border-primary/30 glow-cyan'
                      : 'text-muted-foreground hover:text-foreground hover:bg-muted border border-transparent'
                  )}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{label}</span>
                </Link>
              );
            })}
          </nav>

          {/* Mobile hamburger */}
          <button
            className="sm:hidden ml-auto p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted"
            onClick={() => setMobileOpen(!mobileOpen)}
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          <div className="ml-auto hidden sm:block">
            <span className="font-mono text-[10px] tracking-widest uppercase text-destructive/80 border border-destructive/30 px-2 py-0.5 rounded animate-pulse">
              Classified
            </span>
          </div>
        </div>

        {/* Mobile nav dropdown */}
        {mobileOpen && (
          <nav className="sm:hidden border-t border-border/60 bg-card px-3 py-2 space-y-1">
            {navItems.map(({ path, label, icon: Icon }) => {
              const active = location.pathname === path || 
                (path !== '/' && location.pathname.startsWith(path));
              return (
                <Link
                  key={path}
                  to={path}
                  onClick={() => setMobileOpen(false)}
                  className={cn(
                    'flex items-center gap-2 px-3 py-2.5 rounded-md text-sm font-mono font-medium tracking-wide uppercase transition-all',
                    active
                      ? 'bg-primary/10 text-primary'
                      : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                  )}
                >
                  <Icon className="w-4 h-4" />
                  <span>{label}</span>
                </Link>
              );
            })}
          </nav>
        )}
      </header>

      {/* Main content */}
      <main className="max-w-7xl mx-auto px-3 sm:px-6 py-4 sm:py-6">
        <Outlet />
      </main>
    </div>
  );
}