import React, { useRef, useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { Camera, Upload, FileText, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { decodeQRFromImage, decodeQRFromVideoFrame, validateChunkPayload } from '@/lib/qr-transfer';

export default function ChunkCollector({ onChunkDecoded, collectedCount }) {
  const [activeTab, setActiveTab] = useState('upload');
  const [scanning, setScanning] = useState(false);
  const [lastResult, setLastResult] = useState(null);
  const [manualText, setManualText] = useState('');
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);
  const scanIntervalRef = useRef(null);
  const fileInputRef = useRef(null);

  // Camera scanning
  const startCamera = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } }
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      setScanning(true);
    } catch (err) {
      setLastResult({ type: 'error', message: 'Camera access denied or unavailable' });
    }
  }, []);

  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
      streamRef.current = null;
    }
    clearInterval(scanIntervalRef.current);
    setScanning(false);
  }, []);

  // Scan frames continuously
  useEffect(() => {
    if (!scanning) return;
    scanIntervalRef.current = setInterval(() => {
      if (!videoRef.current || !canvasRef.current) return;
      const decoded = decodeQRFromVideoFrame(videoRef.current, canvasRef.current);
      if (decoded) {
        processPayload(decoded);
      }
    }, 200);
    return () => clearInterval(scanIntervalRef.current);
  }, [scanning]);

  useEffect(() => {
    return () => stopCamera();
  }, []);

  const processPayload = useCallback((payloadStr) => {
    const validation = validateChunkPayload(payloadStr);
    if (!validation.valid) {
      setLastResult({ type: 'error', message: validation.error });
      return;
    }
    const result = onChunkDecoded(validation.chunk);
    setLastResult(result);
  }, [onChunkDecoded]);

  // Batch image upload
  const handleImageUpload = useCallback(async (e) => {
    const files = Array.from(e.target.files);
    let decoded = 0;
    let errors = 0;

    for (const file of files) {
      const dataUrl = await readFileAsDataUrl(file);
      const text = await decodeQRFromImage(dataUrl);
      if (text) {
        const validation = validateChunkPayload(text);
        if (validation.valid) {
          onChunkDecoded(validation.chunk);
          decoded++;
        } else {
          errors++;
        }
      } else {
        errors++;
      }
    }

    setLastResult({
      type: decoded > 0 ? 'success' : 'error',
      message: `Decoded ${decoded} chunks${errors > 0 ? `, ${errors} failed` : ''}`,
    });
  }, [onChunkDecoded]);

  const handleManualImport = useCallback(() => {
    if (!manualText.trim()) return;
    processPayload(manualText.trim());
    setManualText('');
  }, [manualText, processPayload]);

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-semibold">Import Chunks</CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-3 mb-4">
            <TabsTrigger value="upload" className="text-xs gap-1.5">
              <Upload className="w-3.5 h-3.5" /> Images
            </TabsTrigger>
            <TabsTrigger value="camera" className="text-xs gap-1.5">
              <Camera className="w-3.5 h-3.5" /> Camera
            </TabsTrigger>
            <TabsTrigger value="manual" className="text-xs gap-1.5">
              <FileText className="w-3.5 h-3.5" /> Manual
            </TabsTrigger>
          </TabsList>

          <TabsContent value="upload" className="space-y-3">
            <div
              className="border-2 border-dashed rounded-lg p-6 text-center cursor-pointer hover:border-primary/50 transition-colors"
              onClick={() => fileInputRef.current?.click()}
            >
              <Upload className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
              <p className="text-sm font-medium">Upload QR code images</p>
              <p className="text-xs text-muted-foreground mt-1">Select one or more QR code images</p>
            </div>
            <input
              ref={fileInputRef}
              type="file"
              className="hidden"
              accept="image/*"
              multiple
              onChange={handleImageUpload}
            />
          </TabsContent>

          <TabsContent value="camera" className="space-y-3">
            <div className="relative aspect-video bg-black rounded-lg overflow-hidden">
              <video ref={videoRef} className="w-full h-full object-cover" playsInline muted />
              <canvas ref={canvasRef} className="hidden" />
              {!scanning && (
                <div className="absolute inset-0 flex items-center justify-center">
                  <Button onClick={startCamera} className="gap-2">
                    <Camera className="w-4 h-4" />
                    Start Camera
                  </Button>
                </div>
              )}
              {scanning && (
                <div className="absolute top-2 right-2">
                  <Badge className="bg-red-500 text-white animate-pulse">Scanning</Badge>
                </div>
              )}
            </div>
            {scanning && (
              <Button variant="outline" onClick={stopCamera} className="w-full">
                Stop Camera
              </Button>
            )}
          </TabsContent>

          <TabsContent value="manual" className="space-y-3">
            <Textarea
              value={manualText}
              onChange={(e) => setManualText(e.target.value)}
              placeholder="Paste a raw QR chunk JSON payload here..."
              className="font-mono text-xs h-32"
            />
            <Button onClick={handleManualImport} className="w-full" disabled={!manualText.trim()}>
              Import Payload
            </Button>
          </TabsContent>
        </Tabs>

        {/* Status */}
        {lastResult && (
          <div className={`mt-3 flex items-start gap-2 p-2.5 rounded-md text-xs ${
            lastResult.type === 'error' ? 'bg-destructive/10 text-destructive' :
            lastResult.type === 'duplicate' ? 'bg-muted text-muted-foreground' :
            'bg-accent/10 text-accent'
          }`}>
            {lastResult.type === 'error' ? <AlertTriangle className="w-3.5 h-3.5 mt-0.5 shrink-0" /> :
             <CheckCircle2 className="w-3.5 h-3.5 mt-0.5 shrink-0" />}
            <span>{lastResult.message}</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function readFileAsDataUrl(file) {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.readAsDataURL(file);
  });
}