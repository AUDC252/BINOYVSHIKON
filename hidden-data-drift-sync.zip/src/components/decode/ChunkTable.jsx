import React from 'react';
import { Badge } from '@/components/ui/badge';
import { CheckCircle2, AlertCircle, Copy } from 'lucide-react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

export default function ChunkTable({ analysis }) {
  if (!analysis || !analysis.validChunks) return null;

  const { validChunks, totalChunks, invalidChunks, duplicates, missingIndices } = analysis;

  const rows = [];
  for (let i = 0; i < totalChunks; i++) {
    const chunk = validChunks.get(i);
    const isDuplicate = duplicates.includes(i);
    const isMissing = missingIndices.includes(i);

    rows.push({
      index: i,
      status: chunk ? (isDuplicate ? 'duplicate' : 'collected') : (isMissing ? 'missing' : 'invalid'),
      checksum: chunk?.cc || chunk?.k || '—',
      hasData: !!chunk?.d,
    });
  }

  return (
    <div className="rounded-lg border overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow className="bg-muted/50">
            <TableHead className="w-12 sm:w-16 text-xs">#</TableHead>
            <TableHead className="text-xs">Status</TableHead>
            <TableHead className="text-xs hidden sm:table-cell">Checksum</TableHead>
            <TableHead className="text-xs text-right w-12">Data</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {rows.map((row) => (
            <TableRow key={row.index} className="text-xs">
              <TableCell className="font-mono font-medium py-1.5 sm:py-2">{row.index + 1}</TableCell>
              <TableCell className="py-1.5 sm:py-2">
                {row.status === 'collected' && (
                  <Badge className="bg-accent/10 text-accent border-accent/20 text-[9px] sm:text-[10px] px-1.5">
                    <CheckCircle2 className="w-2.5 h-2.5 sm:w-3 sm:h-3 mr-0.5 sm:mr-1" />OK
                  </Badge>
                )}
                {row.status === 'missing' && (
                  <Badge variant="destructive" className="text-[9px] sm:text-[10px] px-1.5">
                    <AlertCircle className="w-2.5 h-2.5 sm:w-3 sm:h-3 mr-0.5 sm:mr-1" />Missing
                  </Badge>
                )}
                {row.status === 'duplicate' && (
                  <Badge variant="secondary" className="text-[9px] sm:text-[10px] px-1.5">
                    <Copy className="w-2.5 h-2.5 sm:w-3 sm:h-3 mr-0.5 sm:mr-1" />Dup
                  </Badge>
                )}
              </TableCell>
              <TableCell className="font-mono text-muted-foreground hidden sm:table-cell py-1.5 sm:py-2 truncate max-w-[120px]">{row.checksum}</TableCell>
              <TableCell className="text-right font-mono py-1.5 sm:py-2">{row.hasData ? '✓' : '—'}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}