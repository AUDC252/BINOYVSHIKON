import React, { useRef, useCallback } from 'react';
import { Upload, Image } from 'lucide-react';

export default function ImageImporter({ onImport, loading }) {
  const inputRef = useRef(null);

  const handleFiles = useCallback((files) => {
    const imageFiles = Array.from(files).filter(f => f.type.startsWith('image/'));
    if (imageFiles.length > 0) onImport(imageFiles);
  }, [onImport]);

  const handleDrop = useCallback((e) => {
    e.preventDefault();
    handleFiles(e.dataTransfer.files);
  }, [handleFiles]);

  return (
    <div
      onDrop={handleDrop}
      onDragOver={(e) => e.preventDefault()}
      onClick={() => inputRef.current?.click()}
      className="rounded-lg border-2 border-dashed border-border hover:border-primary/40 transition-colors cursor-pointer p-8 text-center"
    >
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        multiple
        className="hidden"
        onChange={(e) => e.target.files && handleFiles(e.target.files)}
      />
      <div className="flex items-center justify-center gap-2 mb-2">
        <Image className="w-8 h-8 text-muted-foreground" />
        <Upload className="w-6 h-6 text-muted-foreground" />
      </div>
      <p className="font-medium text-sm">
        {loading ? 'Decoding…' : 'Drop QR code images here or click to browse'}
      </p>
      <p className="text-xs text-muted-foreground mt-1">
        Select multiple QR code images at once — they'll be decoded and matched automatically
      </p>
    </div>
  );
}