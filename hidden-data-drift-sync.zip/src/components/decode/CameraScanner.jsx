import React, { useRef, useEffect, useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Camera, CameraOff } from 'lucide-react';
import QrScanner from 'qr-scanner';
import { parseChunkPayload } from '@/lib/qr-engine/chunking';

export default function CameraScanner({ onChunkDecoded, active }) {
  const videoRef = useRef(null);
  const scannerRef = useRef(null);
  const [scanning, setScanning] = useState(false);
  const [error, setError] = useState(null);
  const lastDecodedRef = useRef(null);

  const startCamera = useCallback(() => {
    setError(null);
    if (!videoRef.current) return;

    const scanner = new QrScanner(
      videoRef.current,
      (result) => {
        const raw = result.data;
        if (raw && raw !== lastDecodedRef.current) {
          lastDecodedRef.current = raw;
          try {
            const chunk = parseChunkPayload(raw);
            onChunkDecoded?.(chunk);
          } catch {
            // Not a valid chunk payload, ignore
          }
          setTimeout(() => { lastDecodedRef.current = null; }, 500);
        }
      },
      {
        returnDetailedScanResult: true,
        preferredCamera: 'environment',
        highlightScanRegion: true,
        highlightCodeOutline: true,
      }
    );

    scannerRef.current = scanner;
    scanner.start()
      .then(() => setScanning(true))
      .catch(() => setError('Camera access denied or not available'));
  }, [onChunkDecoded]);

  const stopCamera = useCallback(() => {
    if (scannerRef.current) {
      scannerRef.current.stop();
      scannerRef.current.destroy();
      scannerRef.current = null;
    }
    setScanning(false);
  }, []);

  // Cleanup on unmount
  useEffect(() => stopCamera, [stopCamera]);

  if (!active) return null;

  return (
    <div className="space-y-3">
      <div className="relative rounded-lg overflow-hidden bg-black aspect-video">
        <video ref={videoRef} className="w-full h-full object-cover" playsInline muted />
        {!scanning && (
          <div className="absolute inset-0 flex items-center justify-center bg-muted/80">
            <Button onClick={startCamera} className="gap-2">
              <Camera className="w-4 h-4" />
              Start Camera
            </Button>
          </div>
        )}
        {scanning && (
          <div className="absolute top-2 right-2 z-10">
            <Button variant="destructive" size="sm" onClick={stopCamera} className="gap-1.5">
              <CameraOff className="w-3.5 h-3.5" />
              Stop
            </Button>
          </div>
        )}
      </div>
      {error && <p className="text-xs text-destructive">{error}</p>}
    </div>
  );
}