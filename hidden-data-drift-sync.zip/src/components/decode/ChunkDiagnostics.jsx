import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Shield, CheckCircle2, AlertTriangle, XCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function ChunkDiagnostics({ validation }) {
  if (!validation) return null;

  const progress = validation.totalExpected > 0
    ? (validation.collectedCount / validation.totalExpected) * 100
    : 0;

  const isComplete = validation.missingChunks.length === 0 && validation.collectedCount > 0;
  const hasErrors = validation.errors.length > 0;
  const hasWarnings = validation.warnings.length > 0;

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-semibold flex items-center gap-2">
          <Shield className="w-4 h-4" />
          Transfer Diagnostics
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Progress */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-xs text-muted-foreground">Collection Progress</span>
            <span className="text-xs font-mono font-medium">
              {validation.collectedCount} / {validation.totalExpected}
            </span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Status */}
        <div className="flex items-center gap-2">
          {isComplete ? (
            <Badge className="bg-accent/10 text-accent border-accent/20 gap-1">
              <CheckCircle2 className="w-3 h-3" /> Complete
            </Badge>
          ) : hasErrors ? (
            <Badge variant="destructive" className="gap-1">
              <XCircle className="w-3 h-3" /> Errors
            </Badge>
          ) : (
            <Badge variant="secondary" className="gap-1">
              <AlertTriangle className="w-3 h-3" /> Incomplete
            </Badge>
          )}
        </div>

        {/* Metadata */}
        {validation.fileName && (
          <div className="text-xs space-y-1.5">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Transfer ID</span>
              <code className="font-mono">{validation.transferId}</code>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">File</span>
              <span className="font-medium truncate ml-2">{validation.fileName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Checksum</span>
              <code className="font-mono">{validation.fileChecksum}</code>
            </div>
          </div>
        )}

        {/* Missing chunks */}
        {validation.missingChunks.length > 0 && (
          <div>
            <p className="text-xs text-muted-foreground mb-1.5">
              Missing Chunks ({validation.missingChunks.length})
            </p>
            <div className="flex flex-wrap gap-1">
              {validation.missingChunks.slice(0, 50).map(i => (
                <Badge key={i} variant="outline" className="text-xs font-mono h-5 px-1.5">
                  {i}
                </Badge>
              ))}
              {validation.missingChunks.length > 50 && (
                <Badge variant="outline" className="text-xs h-5 px-1.5">
                  +{validation.missingChunks.length - 50} more
                </Badge>
              )}
            </div>
          </div>
        )}

        {/* Chunk map visualization */}
        {validation.totalExpected > 0 && validation.totalExpected <= 200 && (
          <div>
            <p className="text-xs text-muted-foreground mb-1.5">Chunk Map</p>
            <div className="flex flex-wrap gap-0.5">
              {Array.from({ length: validation.totalExpected }, (_, i) => {
                const collected = !validation.missingChunks.includes(i);
                return (
                  <div
                    key={i}
                    className={cn(
                      'w-3 h-3 rounded-sm',
                      collected ? 'bg-accent' : 'bg-muted'
                    )}
                    title={`Chunk ${i}: ${collected ? 'collected' : 'missing'}`}
                  />
                );
              })}
            </div>
          </div>
        )}

        {/* Errors */}
        {hasErrors && (
          <div className="space-y-1">
            {validation.errors.map((err, i) => (
              <div key={i} className="text-xs text-destructive flex items-start gap-1.5">
                <XCircle className="w-3 h-3 mt-0.5 shrink-0" />
                {err}
              </div>
            ))}
          </div>
        )}

        {/* Warnings */}
        {hasWarnings && (
          <div className="space-y-1">
            {validation.warnings.map((w, i) => (
              <div key={i} className="text-xs text-chart-3 flex items-start gap-1.5">
                <AlertTriangle className="w-3 h-3 mt-0.5 shrink-0" />
                {w}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}