import React from 'react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Download, CheckCircle2, AlertCircle, Shield } from 'lucide-react';
import { formatBytes } from '@/lib/qr-engine';

export default function ReconstructionPanel({ analysis, onReconstruct, result }) {
  if (!analysis || analysis.collectedChunks === 0) return null;

  const { complete, progress, fileName, fileSize, totalChunks, collectedChunks, missingIndices } = analysis;

  return (
    <div className="rounded-xl border bg-card p-5 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold text-sm">Transfer Progress</h3>
        <Badge variant={complete ? 'default' : 'secondary'} className="text-xs">
          {complete ? 'Complete' : `${collectedChunks} / ${totalChunks}`}
        </Badge>
      </div>

      <Progress value={progress} className="h-2" />

      <div className="grid grid-cols-2 gap-3 text-xs">
        <div>
          <span className="text-muted-foreground">File:</span>
          <p className="font-medium truncate">{fileName}</p>
        </div>
        <div>
          <span className="text-muted-foreground">Size:</span>
          <p className="font-medium">{formatBytes(fileSize)}</p>
        </div>
      </div>

      {missingIndices.length > 0 && (
        <div className="rounded-md bg-destructive/5 border border-destructive/20 p-3 text-xs">
          <div className="flex items-center gap-1.5 text-destructive font-medium mb-1">
            <AlertCircle className="w-3.5 h-3.5" />
            Missing {missingIndices.length} chunk{missingIndices.length > 1 ? 's' : ''}
          </div>
          <p className="text-muted-foreground font-mono">
            Indices: {missingIndices.map(i => i + 1).join(', ')}
          </p>
        </div>
      )}

      {complete && !result && (
        <Button onClick={onReconstruct} className="w-full gap-2">
          <Shield className="w-4 h-4" /> Reconstruct File
        </Button>
      )}

      {result && (
        <div className={`rounded-md p-3 text-xs ${result.checksumMatch ? 'bg-accent/10 border border-accent/20' : 'bg-destructive/5 border border-destructive/20'}`}>
          <div className="flex items-center gap-1.5 font-medium mb-1">
            {result.checksumMatch ? (
              <><CheckCircle2 className="w-3.5 h-3.5 text-accent" /> File verified — checksum matches</>
            ) : (
              <><AlertCircle className="w-3.5 h-3.5 text-destructive" /> Checksum mismatch — file may be corrupted</>
            )}
          </div>
          <Button variant="outline" size="sm" className="mt-2 gap-1.5" onClick={() => {
            const blob = new Blob([result.data], { type: analysis.mimeType });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = analysis.fileName;
            a.click();
            URL.revokeObjectURL(url);
          }}>
            <Download className="w-3.5 h-3.5" /> Download File
          </Button>
        </div>
      )}
    </div>
  );
}