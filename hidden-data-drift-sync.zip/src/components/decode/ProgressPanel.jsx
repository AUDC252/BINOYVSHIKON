import React from 'react';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { CheckCircle2, AlertTriangle, XCircle, Layers, Lock } from 'lucide-react';

export default function ProgressPanel({ analysis }) {
  if (!analysis || !analysis.transferId) return null;

  const {
    progress, complete, totalChunks, collectedChunks,
    missingIndices, duplicates, invalidChunks, foreignChunks,
    fileName, transferId, encrypted,
  } = analysis;

  return (
    <div className="rounded-lg border bg-card p-3 sm:p-4 space-y-3 sm:space-y-4">
      <div className="flex items-center justify-between gap-2">
        <h3 className="font-semibold text-xs sm:text-sm flex items-center gap-1.5 sm:gap-2">
          <Layers className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-primary" />
          Progress
        </h3>
        {complete ? (
          <Badge className="bg-accent/10 text-accent border-accent/20 text-[10px]">
            <CheckCircle2 className="w-3 h-3 mr-1" />Complete
          </Badge>
        ) : (
          <Badge variant="secondary" className="text-[10px]">
            {collectedChunks} / {totalChunks}
          </Badge>
        )}
      </div>

      <Progress value={progress} className="h-1.5 sm:h-2" />

      <div className="text-xs text-muted-foreground space-y-1">
        <p className="truncate">Transfer: <span className="font-mono">{transferId}</span></p>
        <p className="truncate">File: <span className="font-medium text-foreground">{fileName}</span></p>
        {encrypted && (
          <div className="flex items-center gap-1.5 text-primary font-medium">
            <Lock className="w-3 h-3" />
            <span>Encrypted</span>
          </div>
        )}
      </div>

      <div className="space-y-1">
        {missingIndices.length > 0 && (
          <div className="flex items-start gap-1.5 sm:gap-2 text-xs">
            <XCircle className="w-3.5 h-3.5 text-destructive shrink-0 mt-0.5" />
            <span className="break-all">Missing: <span className="font-mono">{missingIndices.map(i => i + 1).join(', ')}</span></span>
          </div>
        )}
        {duplicates.length > 0 && (
          <div className="flex items-start gap-1.5 sm:gap-2 text-xs">
            <AlertTriangle className="w-3.5 h-3.5 text-yellow-600 shrink-0 mt-0.5" />
            <span>{duplicates.length} duplicate(s) ignored</span>
          </div>
        )}
        {invalidChunks.length > 0 && (
          <div className="flex items-start gap-1.5 sm:gap-2 text-xs">
            <XCircle className="w-3.5 h-3.5 text-destructive shrink-0 mt-0.5" />
            <span>{invalidChunks.length} invalid chunk(s)</span>
          </div>
        )}
        {foreignChunks.length > 0 && (
          <div className="flex items-start gap-1.5 sm:gap-2 text-xs">
            <AlertTriangle className="w-3.5 h-3.5 text-yellow-600 shrink-0 mt-0.5" />
            <span>{foreignChunks.length} from different transfer</span>
          </div>
        )}
      </div>
    </div>
  );
}