import React, { useState, useCallback, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Upload, FolderOpen, Camera, Download, CheckCircle2, AlertTriangle, RotateCcw, Loader2, Lock, Eye, EyeOff } from 'lucide-react';
import { decodeColorGrid, reconstructFromPages } from '@/lib/colorgrid';
import { crc32Bytes } from '@/lib/qr-engine/checksum';
import { formatBytes } from '@/lib/qr-engine';
import { toast } from 'sonner';

export default function ColorGridDecoder() {
  const [decodedPages, setDecodedPages] = useState([]);
  const [reconstruction, setReconstruction] = useState(null);
  const [decoding, setDecoding] = useState(false);
  const [progress, setProgress] = useState(null);
  const [logs, setLogs] = useState([]);
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const fileInputRef = useRef(null);
  const folderInputRef = useRef(null);

  const totalPages = decodedPages.length > 0 ? decodedPages[0].header.totalPages : null;
  const collectedIndices = new Set(decodedPages.map(p => p.header.pageIndex));

  const addLog = (type, msg) => setLogs(prev => [...prev, { type, msg }]);

  const processImages = useCallback(async (files) => {
    const imageFiles = Array.from(files).filter(f =>
      f.type.startsWith('image/') || /\.(png|jpg|jpeg|bmp|webp)$/i.test(f.name)
    );
    if (imageFiles.length === 0) {
      toast.error('No image files found');
      return;
    }

    setDecoding(true);
    setProgress({ done: 0, total: imageFiles.length });
    let newPages = [];

    for (let i = 0; i < imageFiles.length; i++) {
      setProgress({ done: i + 1, total: imageFiles.length });
      try {
        // Load image
        const img = await loadImage(imageFiles[i]);
        const result = await decodeColorGrid(img);
        
        // Check for duplicate
        if (collectedIndices.has(result.header.pageIndex)) {
          addLog('warn', `Page ${result.header.pageIndex + 1} already collected — skipped`);
          continue;
        }

        newPages.push(result);
        collectedIndices.add(result.header.pageIndex);
        addLog('success', `Page ${result.header.pageIndex + 1}/${result.header.totalPages} decoded (${result.totalErrors} EC errors)`);
      } catch (err) {
        addLog('error', `${imageFiles[i].name}: ${err.message}`);
      }
    }

    setDecodedPages(prev => [...prev, ...newPages]);
    if (newPages.length > 0) {
      toast.success(`Decoded ${newPages.length} page(s)`);
    }
    setDecoding(false);
  }, [decodedPages, collectedIndices]);

  const handleReconstruct = useCallback(() => {
    const isEncrypted = decodedPages.length > 0 && decodedPages[0].header.encrypted;
    if (isEncrypted && !password) {
      toast.error('This file is encrypted. Enter the password first.');
      return;
    }
    try {
      const result = reconstructFromPages(decodedPages, password || null);
      const actualChecksum = crc32Bytes(result.data);
      const checksumMatch = actualChecksum === result.checksum;
      
      setReconstruction({
        ...result,
        actualChecksum,
        checksumMatch,
        blob: new Blob([result.data], { type: 'application/octet-stream' }),
      });
      
      if (checksumMatch) {
        toast.success('File reconstructed — checksum verified!');
      } else {
        toast.warning('File reconstructed but checksum does not match');
      }
    } catch (err) {
      toast.error(err.message);
    }
  }, [decodedPages, password]);

  const handleDownload = useCallback(() => {
    if (!reconstruction) return;
    const url = URL.createObjectURL(reconstruction.blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = reconstruction.fileName;
    a.click();
    URL.revokeObjectURL(url);
  }, [reconstruction]);

  const handleReset = () => {
    setDecodedPages([]);
    setReconstruction(null);
    setLogs([]);
    setProgress(null);
    setPassword('');
  };

  const isEncrypted = decodedPages.length > 0 && decodedPages[0].header.encrypted;
  const isComplete = totalPages !== null && collectedIndices.size >= totalPages;
  const missingPages = [];
  if (totalPages) {
    for (let i = 0; i < totalPages; i++) {
      if (!collectedIndices.has(i)) missingPages.push(i + 1);
    }
  }

  return (
    <div className="space-y-4">
      {/* Import controls */}
      <div className="rounded-xl border bg-card p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-medium">Import ColorGrid Pages</h3>
          {decodedPages.length > 0 && (
            <Button variant="ghost" size="sm" onClick={handleReset} className="gap-1 text-xs">
              <RotateCcw className="w-3 h-3" /> Reset
            </Button>
          )}
        </div>

        <input ref={fileInputRef} type="file" accept="image/*" multiple className="hidden"
          onChange={(e) => processImages(e.target.files)} />
        <input ref={folderInputRef} type="file" accept="image/*" className="hidden"
          onChange={(e) => processImages(e.target.files)} webkitdirectory="" directory="" />

        <div className="flex flex-col sm:flex-row gap-2">
          <Button variant="outline" className="flex-1 gap-2 text-xs" onClick={() => fileInputRef.current?.click()} disabled={decoding}>
            <Upload className="w-3.5 h-3.5" />
            {decoding && progress ? `Decoding ${progress.done}/${progress.total}...` : 'Upload Images'}
          </Button>
          <Button variant="outline" className="flex-1 gap-2 text-xs" onClick={() => folderInputRef.current?.click()} disabled={decoding}>
            <FolderOpen className="w-3.5 h-3.5" /> Upload Folder
          </Button>
        </div>

        {decoding && progress && (
          <Progress value={(progress.done / progress.total) * 100} className="h-1.5" />
        )}
      </div>

      {/* Progress */}
      {totalPages !== null && (
        <div className="rounded-xl border bg-card p-4 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-medium">Collection Progress</h3>
            <Badge variant={isComplete ? 'default' : 'secondary'} className="text-xs">
              {isComplete ? <><CheckCircle2 className="w-3 h-3 mr-1" /> Complete</> : `${collectedIndices.size} / ${totalPages}`}
            </Badge>
          </div>
          <Progress value={(collectedIndices.size / totalPages) * 100} className="h-2" />
          
          {decodedPages.length > 0 && (
            <div className="text-xs text-muted-foreground space-y-1">
              <p>File: <strong className="text-foreground break-all">{decodedPages[0].header.fileName}</strong></p>
              <p>Size: <strong className="text-foreground">{formatBytes(decodedPages[0].header.fileSize)}</strong></p>
            </div>
          )}

          {missingPages.length > 0 && missingPages.length <= 20 && (
            <p className="text-xs text-yellow-600">
              Missing pages: <span className="font-mono">{missingPages.join(', ')}</span>
            </p>
          )}
          {missingPages.length > 20 && (
            <p className="text-xs text-yellow-600">
              {missingPages.length} pages still missing
            </p>
          )}

          {/* Page map */}
          <div className="flex flex-wrap gap-1">
            {Array.from({ length: totalPages }, (_, i) => (
              <div key={i} className={`w-5 h-5 rounded text-[8px] flex items-center justify-center font-mono ${
                collectedIndices.has(i) ? 'bg-accent/20 text-accent border border-accent/30' : 'bg-muted text-muted-foreground border border-border'
              }`}>
                {i + 1}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Encryption password — always show when complete so user can enter if needed */}
      {isComplete && !reconstruction && (
        <div className="rounded-xl border border-primary/30 bg-primary/5 p-4 space-y-2">
          <div className="flex items-center gap-2 text-sm font-medium text-primary">
            <Lock className="w-4 h-4" /> Decryption Password (if encrypted)
          </div>
          <p className="text-xs text-muted-foreground">If the file was encrypted during encoding, enter the password here. Leave empty if no password was used.</p>
          <div className="relative">
            <Input
              type={showPassword ? 'text' : 'password'}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Decryption password (optional)"
              className="pr-10 font-mono text-sm"
            />
            <button type="button" onClick={() => setShowPassword(!showPassword)}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
        </div>
      )}

      {/* Reconstruct */}
      {isComplete && !reconstruction && (
        <Button className="w-full gap-2" onClick={handleReconstruct}>
          <CheckCircle2 className="w-4 h-4" /> Reconstruct File
        </Button>
      )}

      {reconstruction && (
        <div className="rounded-xl border bg-card p-4 space-y-3">
          <div className="flex items-center gap-2">
            {reconstruction.checksumMatch ? (
              <Badge className="bg-accent/10 text-accent border-accent/20">
                <CheckCircle2 className="w-3 h-3 mr-1" /> Checksum Verified
              </Badge>
            ) : (
              <Badge variant="destructive">
                <AlertTriangle className="w-3 h-3 mr-1" /> Checksum Mismatch
              </Badge>
            )}
          </div>
          <div className="text-xs space-y-1">
            <p>File: <strong className="break-all">{reconstruction.fileName}</strong></p>
            <p>Size: {formatBytes(reconstruction.fileSize)}</p>
          </div>
          <Button className="w-full gap-2" onClick={handleDownload}>
            <Download className="w-4 h-4" /> Download File
          </Button>
        </div>
      )}

      {/* Activity log */}
      {logs.length > 0 && (
        <div className="rounded-xl border bg-card p-4">
          <h3 className="text-sm font-medium mb-2">Activity Log</h3>
          <div className="max-h-36 overflow-y-auto space-y-1">
            {logs.map((entry, i) => (
              <div key={i} className="flex items-start gap-2 text-xs font-mono">
                <span className={entry.type === 'success' ? 'text-accent' : entry.type === 'error' ? 'text-destructive' : 'text-yellow-600'}>
                  {entry.type === 'success' ? '✓' : entry.type === 'error' ? '✗' : '⚠'}
                </span>
                <span className="text-muted-foreground break-all">{entry.msg}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// Helper: load File as HTMLImageElement
function loadImage(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => { URL.revokeObjectURL(url); resolve(img); };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('Cannot load image')); };
    img.src = url;
  });
}