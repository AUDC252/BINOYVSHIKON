import React, { useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Printer, Download, ChevronLeft, ChevronRight } from 'lucide-react';

export default function PrintPreview({ pages, currentPage, onPageChange }) {
  const canvasRef = useRef(null);
  const page = pages[currentPage];

  // Draw the page canvas into the visible preview canvas
  React.useEffect(() => {
    if (!page || !canvasRef.current) return;
    const ctx = canvasRef.current.getContext('2d');
    const srcCanvas = page.canvas;
    canvasRef.current.width = srcCanvas.width;
    canvasRef.current.height = srcCanvas.height;
    ctx.drawImage(srcCanvas, 0, 0);
  }, [page]);

  const handlePrint = () => {
    if (!page) return;
    const dataUrl = page.canvas.toDataURL('image/png');
    const win = window.open('', '_blank');
    win.document.write(`
      <html><head><title>ColorGrid Page ${currentPage + 1}</title>
      <style>@page{size:A4;margin:0}body{margin:0;display:flex;justify-content:center;align-items:center;height:100vh}
      img{width:100%;height:auto;max-height:100vh;object-fit:contain}</style></head>
      <body><img src="${dataUrl}" onload="window.print();"/></body></html>
    `);
    win.document.close();
  };

  const handleDownloadPNG = () => {
    if (!page) return;
    const link = document.createElement('a');
    link.download = `colorgrid_page_${String(currentPage + 1).padStart(3, '0')}.png`;
    link.href = page.canvas.toDataURL('image/png');
    link.click();
  };

  const handleDownloadAll = () => {
    for (let i = 0; i < pages.length; i++) {
      const link = document.createElement('a');
      link.download = `colorgrid_page_${String(i + 1).padStart(3, '0')}.png`;
      link.href = pages[i].canvas.toDataURL('image/png');
      link.click();
    }
  };

  if (!page) return null;

  return (
    <div className="space-y-4">
      {/* Navigation */}
      <div className="flex items-center justify-between">
        <Button
          variant="outline" size="sm"
          onClick={() => onPageChange(Math.max(0, currentPage - 1))}
          disabled={currentPage === 0}
        >
          <ChevronLeft className="w-4 h-4" />
        </Button>
        <span className="font-mono text-sm text-muted-foreground">
          Page {currentPage + 1} / {pages.length}
        </span>
        <Button
          variant="outline" size="sm"
          onClick={() => onPageChange(Math.min(pages.length - 1, currentPage + 1))}
          disabled={currentPage === pages.length - 1}
        >
          <ChevronRight className="w-4 h-4" />
        </Button>
      </div>

      {/* Preview */}
      <div className="rounded-lg border bg-white overflow-hidden flex justify-center">
        <canvas
          ref={canvasRef}
          className="max-w-full h-auto"
          style={{ maxHeight: '60vh' }}
        />
      </div>

      {/* Actions */}
      <div className="flex flex-wrap gap-2">
        <Button onClick={handlePrint} className="gap-2 flex-1">
          <Printer className="w-4 h-4" /> Print This Page
        </Button>
        <Button variant="outline" onClick={handleDownloadPNG} className="gap-2 flex-1">
          <Download className="w-4 h-4" /> Download PNG
        </Button>
        {pages.length > 1 && (
          <Button variant="secondary" onClick={handleDownloadAll} className="gap-2 w-full">
            <Download className="w-4 h-4" /> Download All {pages.length} Pages
          </Button>
        )}
      </div>
    </div>
  );
}