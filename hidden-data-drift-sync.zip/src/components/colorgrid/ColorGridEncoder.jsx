import React, { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Loader2, Printer, Download, ChevronLeft, ChevronRight, Palette } from 'lucide-react';
import { encodeToColorGrid, canvasToDataUrl, canvasToBlob, getCapacityInfo } from '@/lib/colorgrid';
import { formatBytes } from '@/lib/qr-engine';

export default function ColorGridEncoder({ file, password }) {
  const [pages, setPages] = useState(null);
  const [generating, setGenerating] = useState(false);
  const [currentPage, setCurrentPage] = useState(0);
  const [dataUrls, setDataUrls] = useState([]);

  const capacityInfo = getCapacityInfo();

  const handleGenerate = useCallback(async () => {
    if (!file) return;
    setGenerating(true);
    
    const arrayBuffer = await file.arrayBuffer();
    const result = encodeToColorGrid(arrayBuffer, file.name, file.type, password || null);
    setPages(result);
    
    // Generate data URLs for display
    const urls = result.map(p => canvasToDataUrl(p.canvas));
    setDataUrls(urls);
    setCurrentPage(0);
    setGenerating(false);
  }, [file]);

  const handleDownloadPage = useCallback(async (idx) => {
    if (!pages || !pages[idx]) return;
    const blob = await canvasToBlob(pages[idx].canvas);
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${file.name}_page_${idx + 1}.png`;
    a.click();
    URL.revokeObjectURL(url);
  }, [pages, file]);

  const handleDownloadAll = useCallback(async () => {
    if (!pages) return;
    const JSZip = (await import('jszip')).default;
    const zip = new JSZip();
    const folder = zip.folder(file.name.replace(/\.[^.]+$/, '') + '_colorgrid');
    for (let i = 0; i < pages.length; i++) {
      const blob = await canvasToBlob(pages[i].canvas);
      folder.file(`page_${String(i + 1).padStart(3, '0')}.png`, blob);
    }
    const zipBlob = await zip.generateAsync({ type: 'blob' });
    const url = URL.createObjectURL(zipBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${file.name.replace(/\.[^.]+$/, '')}_colorgrid.zip`;
    a.click();
    URL.revokeObjectURL(url);
  }, [pages, file]);

  const handlePrint = useCallback(() => {
    if (!dataUrls[currentPage]) return;
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
      <html><head><title>ColorGrid Page ${currentPage + 1}</title>
      <style>@page{size:A4;margin:0}body{margin:0;display:flex;justify-content:center;align-items:center;height:100vh}
      img{max-width:100%;max-height:100vh;}</style></head>
      <body><img src="${dataUrls[currentPage]}" onload="window.print();window.close()"></body></html>
    `);
  }, [dataUrls, currentPage]);

  const estimatedPages = file ? Math.ceil(file.size / capacityInfo.netCapacityPerPage) : 0;

  if (!pages) {
    return (
      <div className="space-y-4">
        <div className="rounded-xl border bg-card p-4 sm:p-5 space-y-3">
          <div className="flex items-center gap-2 text-sm font-medium">
            <Palette className="w-4 h-4 text-primary" />
            Color Grid Encoding
          </div>
          <div className="text-xs text-muted-foreground space-y-1">
            <p>File: <strong className="text-foreground break-all">{file?.name}</strong></p>
            <p>Size: <strong className="text-foreground">{file ? formatBytes(file.size) : '—'}</strong></p>
            <p>Capacity per page: <strong className="text-foreground">{formatBytes(capacityInfo.netCapacityPerPage)}</strong></p>
            <p>Estimated pages: <strong className="text-foreground">{estimatedPages}</strong></p>
          </div>
          <Button onClick={handleGenerate} disabled={generating || !file} className="w-full gap-2">
            {generating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Palette className="w-4 h-4" />}
            {generating ? 'Generating ColorGrid...' : 'Generate ColorGrid Pages'}
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Page viewer */}
      <div className="rounded-xl border bg-card overflow-hidden">
        <div className="p-3 border-b flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="text-xs">
              Page {currentPage + 1} / {pages.length}
            </Badge>
            <span className="text-xs text-muted-foreground">
              {formatBytes(pages[currentPage].dataSize)} on this page
            </span>
          </div>
          <div className="flex gap-1">
            <Button variant="ghost" size="icon" className="h-7 w-7"
              onClick={() => setCurrentPage(Math.max(0, currentPage - 1))}
              disabled={currentPage === 0}>
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="icon" className="h-7 w-7"
              onClick={() => setCurrentPage(Math.min(pages.length - 1, currentPage + 1))}
              disabled={currentPage === pages.length - 1}>
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
        
        <div className="bg-white p-2 flex justify-center">
          <img
            src={dataUrls[currentPage]}
            alt={`ColorGrid page ${currentPage + 1}`}
            className="max-h-[400px] sm:max-h-[500px] object-contain"
          />
        </div>

        <div className="p-3 border-t">
          <Progress value={(currentPage + 1) / pages.length * 100} className="h-1.5 mb-3" />
          <div className="flex flex-col sm:flex-row gap-2">
            <Button variant="outline" className="flex-1 gap-2 text-xs" onClick={() => handleDownloadPage(currentPage)}>
              <Download className="w-3.5 h-3.5" /> Download This Page
            </Button>
            <Button variant="outline" className="flex-1 gap-2 text-xs" onClick={handleDownloadAll}>
              <Download className="w-3.5 h-3.5" /> Download All ({pages.length})
            </Button>
            <Button className="flex-1 gap-2 text-xs" onClick={handlePrint}>
              <Printer className="w-3.5 h-3.5" /> Print This Page
            </Button>
          </div>
        </div>
      </div>

      {/* Page grid thumbnails */}
      {pages.length > 1 && (
        <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-2">
          {dataUrls.map((url, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentPage(idx)}
              className={`rounded-lg border-2 overflow-hidden transition-all ${
                idx === currentPage ? 'border-primary ring-2 ring-primary/30' : 'border-border hover:border-muted-foreground'
              }`}
            >
              <img src={url} alt={`Page ${idx + 1}`} className="w-full aspect-[3/4] object-cover bg-white" />
              <div className="text-[9px] text-center py-0.5 bg-muted">{idx + 1}</div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}