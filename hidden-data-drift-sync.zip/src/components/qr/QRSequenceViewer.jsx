import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { 
  ChevronLeft, ChevronRight, Play, Pause, SkipBack, SkipForward,
  Download, Grid3X3, Maximize2
} from 'lucide-react';
import { Progress } from '@/components/ui/progress';

export default function QRSequenceViewer({ qrImages, chunks, onExportAll, onExportPDF }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1000); // ms per frame
  const [viewMode, setViewMode] = useState('single'); // single | grid
  const intervalRef = useRef(null);

  const total = qrImages.length;
  const current = qrImages[currentIndex];
  const currentChunk = chunks[currentIndex];

  useEffect(() => {
    if (isPlaying) {
      intervalRef.current = setInterval(() => {
        setCurrentIndex(prev => {
          if (prev >= total - 1) {
            setIsPlaying(false);
            return prev;
          }
          return prev + 1;
        });
      }, playbackSpeed);
    }
    return () => clearInterval(intervalRef.current);
  }, [isPlaying, playbackSpeed, total]);

  const goTo = useCallback((idx) => {
    setCurrentIndex(Math.max(0, Math.min(total - 1, idx)));
  }, [total]);

  if (viewMode === 'grid') {
    return (
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm font-semibold">QR Grid — {total} codes</CardTitle>
            <div className="flex gap-2">
              {onExportAll && (
                <Button size="sm" variant="outline" onClick={onExportAll} className="text-xs gap-1.5">
                  <Download className="w-3.5 h-3.5" /> Export All
                </Button>
              )}
              <Button size="sm" variant="outline" onClick={() => setViewMode('single')} className="text-xs gap-1.5">
                <Maximize2 className="w-3.5 h-3.5" /> Single View
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-3">
            {qrImages.map((qr, i) => (
              <div
                key={i}
                className="cursor-pointer border rounded-md p-1 hover:border-primary transition-colors"
                onClick={() => { setCurrentIndex(i); setViewMode('single'); }}
              >
                <img src={qr.dataUrl} alt={`Chunk ${i}`} className="w-full aspect-square" />
                <p className="text-center text-xs text-muted-foreground mt-1">#{i + 1}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-semibold">
            QR Sequence — Chunk {currentIndex + 1} of {total}
          </CardTitle>
          <div className="flex gap-2">
            {onExportAll && (
              <Button size="sm" variant="outline" onClick={onExportAll} className="text-xs gap-1.5">
                <Download className="w-3.5 h-3.5" /> Export
              </Button>
            )}
            <Button size="sm" variant="outline" onClick={() => setViewMode('grid')} className="text-xs gap-1.5">
              <Grid3X3 className="w-3.5 h-3.5" /> Grid
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* QR Display */}
        <div className="flex justify-center">
          <div className="bg-white p-3 rounded-lg shadow-sm inline-block">
            {current && (
              <img
                src={current.dataUrl}
                alt={`QR Chunk ${currentIndex + 1}`}
                className="w-64 h-64 sm:w-72 sm:h-72"
              />
            )}
          </div>
        </div>

        {/* Progress */}
        <Progress value={((currentIndex + 1) / total) * 100} className="h-1.5" />

        {/* Controls */}
        <div className="flex items-center justify-center gap-2">
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => goTo(0)}>
            <SkipBack className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => goTo(currentIndex - 1)}>
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <Button
            variant={isPlaying ? 'secondary' : 'default'}
            size="icon"
            className="h-10 w-10"
            onClick={() => setIsPlaying(!isPlaying)}
          >
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          </Button>
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => goTo(currentIndex + 1)}>
            <ChevronRight className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => goTo(total - 1)}>
            <SkipForward className="w-4 h-4" />
          </Button>
        </div>

        {/* Speed control */}
        <div className="flex items-center gap-3">
          <span className="text-xs text-muted-foreground whitespace-nowrap">Speed</span>
          <Slider
            value={[2000 - playbackSpeed]}
            onValueChange={([val]) => setPlaybackSpeed(2000 - val)}
            min={0}
            max={1800}
            step={100}
            className="flex-1"
          />
          <span className="text-xs font-mono text-muted-foreground w-14 text-right">{playbackSpeed}ms</span>
        </div>

        {/* Chunk meta */}
        {currentChunk && (
          <div className="rounded-md bg-muted p-3 grid grid-cols-2 gap-2 text-xs">
            <div>
              <span className="text-muted-foreground">Chunk Index: </span>
              <span className="font-mono">{currentChunk.ci}</span>
            </div>
            <div>
              <span className="text-muted-foreground">Data Size: </span>
              <span className="font-mono">{currentChunk.cs} B</span>
            </div>
            <div className="col-span-2">
              <span className="text-muted-foreground">Checksum: </span>
              <code className="font-mono bg-background px-1 py-0.5 rounded">{currentChunk.cc}</code>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}