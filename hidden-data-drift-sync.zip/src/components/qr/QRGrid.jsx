import React from 'react';
import { Badge } from '@/components/ui/badge';

export default function QRGrid({ qrCodes, onSelect }) {
  if (!qrCodes || qrCodes.length === 0) return null;

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2 sm:gap-3">
      {qrCodes.map((code, idx) => (
        <button
          key={idx}
          onClick={() => onSelect?.(idx)}
          className="relative bg-white rounded-lg p-1.5 sm:p-2 border hover:border-primary/40 transition-colors group"
        >
          <img src={code.dataUrl} alt={`QR ${idx + 1}`} className="w-full aspect-square" />
          <Badge variant="secondary" className="absolute top-1 right-1 text-[9px] sm:text-[10px] px-1 sm:px-1.5 py-0">
            {idx + 1}
          </Badge>
        </button>
      ))}
    </div>
  );
}