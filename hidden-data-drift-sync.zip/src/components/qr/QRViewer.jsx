import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { ChevronLeft, ChevronRight, Play, Pause, SkipBack, SkipForward, Download } from 'lucide-react';

export default function QRViewer({ qrCodes, chunks, onExportAll }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [speed, setSpeed] = useState(1000);
  const intervalRef = useRef(null);

  const total = qrCodes?.length || 0;
  const current = qrCodes?.[currentIndex];
  const chunk = chunks?.[currentIndex];

  useEffect(() => {
    if (playing && total > 0) {
      intervalRef.current = setInterval(() => {
        setCurrentIndex((prev) => {
          if (prev >= total - 1) { setPlaying(false); return prev; }
          return prev + 1;
        });
      }, speed);
    }
    return () => clearInterval(intervalRef.current);
  }, [playing, speed, total]);

  const goTo = useCallback((idx) => {
    setCurrentIndex(Math.max(0, Math.min(total - 1, idx)));
  }, [total]);

  if (!qrCodes || total === 0) return null;

  return (
    <div className="space-y-3 sm:space-y-4">
      {/* QR Display */}
      <div className="flex justify-center">
        <div className="bg-white rounded-xl p-2 sm:p-3 shadow-sm border">
          <img
            src={current?.dataUrl}
            alt={`QR chunk ${currentIndex + 1}`}
            className="w-48 h-48 sm:w-64 sm:h-64 md:w-72 md:h-72"
          />
        </div>
      </div>

      {/* Chunk info */}
      <div className="text-center space-y-1">
        <div className="flex items-center justify-center gap-2 flex-wrap">
          <Badge variant="outline" className="font-mono text-xs">
            Chunk {currentIndex + 1} / {total}
          </Badge>
          <Badge variant="secondary" className="text-xs">
            {current?.payloadSize} bytes
          </Badge>
        </div>
        {chunk && (
          <p className="text-[10px] sm:text-xs text-muted-foreground font-mono truncate px-4">
            Checksum: {chunk.k || chunk.cc || '—'}
          </p>
        )}
      </div>

      {/* Progress bar */}
      <div className="flex items-center gap-2">
        <span className="text-xs text-muted-foreground w-6 text-right">{currentIndex + 1}</span>
        <Slider value={[currentIndex]} onValueChange={([v]) => goTo(v)} min={0} max={total - 1} step={1} className="flex-1" />
        <span className="text-xs text-muted-foreground w-6">{total}</span>
      </div>

      {/* Controls */}
      <div className="flex items-center justify-center gap-1.5 sm:gap-2">
        <Button variant="outline" size="icon" className="h-8 w-8 sm:h-9 sm:w-9" onClick={() => goTo(0)}>
          <SkipBack className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
        </Button>
        <Button variant="outline" size="icon" className="h-8 w-8 sm:h-9 sm:w-9" onClick={() => goTo(currentIndex - 1)}>
          <ChevronLeft className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
        </Button>
        <Button variant={playing ? 'destructive' : 'default'} size="icon" className="h-8 w-8 sm:h-9 sm:w-9" onClick={() => setPlaying(!playing)}>
          {playing ? <Pause className="w-3.5 h-3.5 sm:w-4 sm:h-4" /> : <Play className="w-3.5 h-3.5 sm:w-4 sm:h-4" />}
        </Button>
        <Button variant="outline" size="icon" className="h-8 w-8 sm:h-9 sm:w-9" onClick={() => goTo(currentIndex + 1)}>
          <ChevronRight className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
        </Button>
        <Button variant="outline" size="icon" className="h-8 w-8 sm:h-9 sm:w-9" onClick={() => goTo(total - 1)}>
          <SkipForward className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
        </Button>
      </div>

      {/* Speed control */}
      <div className="flex items-center gap-2 sm:gap-3 justify-center flex-wrap">
        <span className="text-xs text-muted-foreground">Speed:</span>
        <div className="flex gap-1">
          {[2000, 1000, 500, 200].map((ms) => (
            <Button key={ms} variant={speed === ms ? 'default' : 'outline'} size="sm"
              className="text-[10px] sm:text-xs h-6 sm:h-7 px-1.5 sm:px-2" onClick={() => setSpeed(ms)}>
              {ms >= 1000 ? `${ms / 1000}s` : `${ms}ms`}
            </Button>
          ))}
        </div>
      </div>

      {/* Export */}
      {onExportAll && (
        <div className="flex justify-center">
          <Button variant="outline" size="sm" onClick={onExportAll} className="gap-1.5 text-xs">
            <Download className="w-3.5 h-3.5" /> Export All as ZIP
          </Button>
        </div>
      )}
    </div>
  );
}