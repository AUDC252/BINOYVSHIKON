import React, { useState, useCallback, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Upload, Camera, FileText, Download, CheckCircle2, AlertTriangle, RotateCcw, ImagePlus, FolderOpen, Lock, Eye, EyeOff } from 'lucide-react';
import { Input } from '@/components/ui/input';
import CameraScanner from '@/components/decode/CameraScanner';
import ProgressPanel from '@/components/decode/ProgressPanel';
import ChunkTable from '@/components/decode/ChunkTable';
import {
  batchDecodeQRImages,
  analyzeChunkCollection,
  reconstructFile,
  downloadReconstructedFile,
  parseChunkPayload,
  formatBytes,
} from '@/lib/qr-engine';
import { toast } from 'sonner';

export default function Decode() {
  const [chunks, setChunks] = useState([]);
  const [analysis, setAnalysis] = useState(null);
  const [reconstruction, setReconstruction] = useState(null);
  const [importMode, setImportMode] = useState('upload');
  const [importing, setImporting] = useState(false);
  const [importProgress, setImportProgress] = useState(null);
  const [decodeLog, setDecodeLog] = useState([]);
  const [reconstructing, setReconstructing] = useState(false);
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const fileInputRef = useRef(null);
  const folderInputRef = useRef(null);
  const chunksRef = useRef([]);

  const runAnalysis = useCallback((allChunks) => {
    if (allChunks.length > 0) {
      setAnalysis(analyzeChunkCollection(allChunks));
    }
  }, []);

  // Re-run analysis whenever chunks change
  useEffect(() => {
    runAnalysis(chunks);
  }, [chunks, runAnalysis]);

  const addChunks = useCallback((newChunks, logs) => {
    setChunks(prev => {
      const existing = new Set(prev.map(c => `${c.tid}:${c.ci}`));
      const deduped = newChunks.filter(c => !existing.has(`${c.tid}:${c.ci}`));
      if (deduped.length === 0 && newChunks.length > 0 && logs) {
        logs.push({ type: 'warn', msg: `${newChunks.length} duplicate chunk(s) ignored` });
      }
      const updated = [...prev, ...deduped];
      chunksRef.current = updated;
      return updated;
    });
  }, []);

  const addSingleChunk = useCallback((chunk) => {
    const exists = chunksRef.current.some(c => c.tid === chunk.tid && c.ci === chunk.ci);
    if (exists) {
      setDecodeLog(l => [...l, { type: 'warn', msg: `Duplicate chunk #${chunk.ci + 1} ignored` }]);
      return;
    }
    setDecodeLog(l => [...l, { type: 'success', msg: `Chunk #${chunk.ci + 1} collected (${chunk.tid})` }]);
    addChunks([chunk], null);
  }, [addChunks]);

  const handleImageUpload = useCallback(async (e) => {
    const allFiles = Array.from(e.target.files || []);
    const imageExts = ['.png', '.jpg', '.jpeg', '.gif', '.bmp', '.webp', '.svg'];
    const files = allFiles.filter(f => 
      f.type.startsWith('image/') || 
      imageExts.some(ext => f.name.toLowerCase().endsWith(ext))
    );
    if (files.length === 0) {
      toast.error('No image files found');
      return;
    }

    setImporting(true);
    setImportProgress({ done: 0, total: files.length });
    const results = await batchDecodeQRImages(files, (done, total) => {
      setImportProgress({ done, total });
    });

    const newChunks = [];
    const newLogs = [];
    for (const result of results) {
      if (result.success) {
        newChunks.push(result.chunk);
        newLogs.push({ type: 'success', msg: `Chunk #${result.chunk.ci + 1} collected (${result.chunk.tid})` });
      } else {
        newLogs.push({ type: 'error', msg: `${result.fileName}: ${result.error}` });
      }
    }

    addChunks(newChunks, newLogs);
    setDecodeLog(l => [...l, ...newLogs]);
    toast.success(`Decoded ${newChunks.length} of ${files.length} file(s)`);
    setImporting(false);
    if (fileInputRef.current) fileInputRef.current.value = '';
    if (folderInputRef.current) folderInputRef.current.value = '';
  }, [addChunks]);

  const handleCameraChunk = useCallback((chunk) => {
    addSingleChunk(chunk);
    toast.success(`Scanned chunk #${chunk.ci + 1}`);
  }, [addSingleChunk]);

  const handleReconstruct = useCallback(() => {
    if (!analysis || !analysis.complete) {
      toast.error('Cannot reconstruct: collection is incomplete');
      return;
    }
    if (analysis.encrypted && !password) {
      toast.error('This transfer is encrypted. Enter the password first.');
      return;
    }
    setReconstructing(true);
    try {
      const result = reconstructFile(analysis, password || null);
      setReconstruction(result);
      toast.success('File reconstructed successfully! Checksum verified.');
    } catch (err) {
      toast.error(err.message);
    } finally {
      setReconstructing(false);
    }
  }, [analysis, password]);

  const handleDownload = useCallback(() => {
    if (reconstruction) downloadReconstructedFile(reconstruction);
  }, [reconstruction]);

  const handleReset = useCallback(() => {
    setChunks([]);
    chunksRef.current = [];
    setAnalysis(null);
    setReconstruction(null);
    setDecodeLog([]);
    setReconstructing(false);
    setPassword('');
  }, []);

  const handleManualPaste = useCallback(() => {
    const input = prompt('Paste a QR payload JSON string:');
    if (!input) return;
    try {
      const chunk = parseChunkPayload(input);
      addSingleChunk(chunk);
      toast.success(`Chunk #${chunk.ci + 1} added manually`);
    } catch {
      toast.error('Invalid payload format');
    }
  }, [addSingleChunk]);

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold">Decode & Reconstruct</h1>
          <p className="text-xs sm:text-sm text-muted-foreground mt-1">
            Scan or import QR chunks to rebuild the original file
          </p>
        </div>
        {chunks.length > 0 && (
          <Button variant="outline" size="sm" onClick={handleReset} className="gap-1.5 shrink-0">
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Reset</span>
          </Button>
        )}
      </div>

      {/* Mobile: stack vertically. Desktop: 3-col */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
        {/* Left: Input */}
        <div className="space-y-3 sm:space-y-4">
          <Card>
            <CardHeader className="pb-2 sm:pb-3 px-3 sm:px-6 pt-3 sm:pt-6">
              <CardTitle className="text-sm">Import QR Codes</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 sm:space-y-4 px-3 sm:px-6 pb-3 sm:pb-6">
              <Tabs value={importMode} onValueChange={setImportMode}>
                <TabsList className="w-full">
                  <TabsTrigger value="upload" className="flex-1 text-xs gap-1">
                    <ImagePlus className="w-3 h-3" />
                    Upload
                  </TabsTrigger>
                  <TabsTrigger value="camera" className="flex-1 text-xs gap-1">
                    <Camera className="w-3 h-3" />
                    Camera
                  </TabsTrigger>
                </TabsList>
              </Tabs>

              {importMode === 'upload' && (
                <div className="space-y-2">
                  <input ref={fileInputRef} type="file" accept="image/*" multiple className="hidden" onChange={handleImageUpload} />
                  <input ref={folderInputRef} type="file" accept="image/*" className="hidden" onChange={handleImageUpload} webkitdirectory="" directory="" />
                  <Button variant="outline" className="w-full gap-2 text-xs sm:text-sm" onClick={() => fileInputRef.current?.click()} disabled={importing}>
                    <Upload className="w-4 h-4" />
                    {importing && importProgress ? `Decoding ${importProgress.done}/${importProgress.total}...` : 'Upload QR Images'}
                  </Button>
                  <Button variant="outline" className="w-full gap-2 text-xs sm:text-sm" onClick={() => folderInputRef.current?.click()} disabled={importing}>
                    <FolderOpen className="w-4 h-4" />
                    {importing && importProgress ? `Decoding ${importProgress.done}/${importProgress.total}...` : 'Upload Folder'}
                  </Button>
                </div>
              )}

              {importMode === 'camera' && (
                <CameraScanner active={importMode === 'camera'} onChunkDecoded={handleCameraChunk} />
              )}

              <Button variant="ghost" size="sm" className="w-full text-xs gap-1.5" onClick={handleManualPaste}>
                <FileText className="w-3 h-3" /> Paste Raw Payload
              </Button>
            </CardContent>
          </Card>

          <ProgressPanel analysis={analysis} />

          {/* Missing chunks */}
          {analysis && !analysis.complete && analysis.missingIndices.length > 0 && (
            <Card className="border-yellow-500/30 bg-yellow-500/5">
              <CardContent className="pt-3 sm:pt-4 space-y-2 sm:space-y-3 px-3 sm:px-6 pb-3 sm:pb-6">
                <div className="flex items-center gap-2 text-sm font-medium text-yellow-700">
                  <AlertTriangle className="w-4 h-4" />
                  {analysis.missingIndices.length} Missing Chunk(s)
                </div>
                <p className="text-xs text-muted-foreground">
                  Chunks: <span className="font-mono">{analysis.missingIndices.map(i => i + 1).join(', ')}</span>
                </p>
                <div className="flex flex-col gap-1.5">
                  <Button variant="outline" size="sm" className="w-full gap-1.5 text-xs" onClick={() => fileInputRef.current?.click()} disabled={importing}>
                    <Upload className="w-3.5 h-3.5" /> Add More Images
                  </Button>
                  <Button variant="outline" size="sm" className="w-full gap-1.5 text-xs" onClick={() => folderInputRef.current?.click()} disabled={importing}>
                    <FolderOpen className="w-3.5 h-3.5" /> Add From Folder
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Reconstruct */}
          {analysis?.complete && !reconstruction && (
            <div className="space-y-3">
              {analysis.encrypted && (
                <Card className="border-primary/30 bg-primary/5">
                  <CardContent className="pt-3 sm:pt-4 space-y-2 px-3 sm:px-6 pb-3 sm:pb-6">
                    <div className="flex items-center gap-2 text-sm font-medium text-primary">
                      <Lock className="w-4 h-4" /> Encrypted Transfer
                    </div>
                    <p className="text-xs text-muted-foreground">Enter the password to decrypt.</p>
                    <div className="relative">
                      <Input
                        type={showPassword ? 'text' : 'password'}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="Decryption password"
                        className="pr-10 font-mono text-sm"
                      />
                      <button type="button" onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </CardContent>
                </Card>
              )}
              <Button className="w-full gap-2" onClick={handleReconstruct}
                disabled={reconstructing || (analysis.encrypted && !password)}>
                <CheckCircle2 className="w-4 h-4" />
                {reconstructing ? 'Reconstructing…' : 'Reconstruct File'}
              </Button>
            </div>
          )}

          {reconstruction && (
            <Card>
              <CardContent className="pt-3 sm:pt-4 space-y-3 px-3 sm:px-6 pb-3 sm:pb-6">
                <div className="flex items-center gap-2">
                  {reconstruction.checksumMatch ? (
                    <Badge className="bg-accent/10 text-accent border-accent/20">
                      <CheckCircle2 className="w-3 h-3 mr-1" /> Checksum Verified
                    </Badge>
                  ) : (
                    <Badge variant="destructive">
                      <AlertTriangle className="w-3 h-3 mr-1" /> Checksum Mismatch
                    </Badge>
                  )}
                </div>
                <div className="text-xs space-y-1">
                  <p>File: <strong className="break-all">{reconstruction.fileName}</strong></p>
                  <p>Size: {formatBytes(reconstruction.fileSize)}</p>
                </div>
                <Button className="w-full gap-2" onClick={handleDownload}>
                  <Download className="w-4 h-4" /> Download File
                </Button>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Right: Chunk table & log */}
        <div className="lg:col-span-2 space-y-3 sm:space-y-4">
          {analysis ? (
            <ChunkTable analysis={analysis} />
          ) : (
            <div className="rounded-xl border-2 border-dashed border-border flex items-center justify-center min-h-[200px] sm:min-h-[300px]">
              <div className="text-center text-muted-foreground p-6">
                <Camera className="w-8 h-8 sm:w-10 sm:h-10 mx-auto mb-3 opacity-30" />
                <p className="text-sm font-medium">No chunks collected yet</p>
                <p className="text-xs mt-1">Upload QR images or scan with camera</p>
              </div>
            </div>
          )}

          {decodeLog.length > 0 && (
            <Card>
              <CardHeader className="pb-2 px-3 sm:px-6 pt-3 sm:pt-6">
                <CardTitle className="text-sm">Activity Log</CardTitle>
              </CardHeader>
              <CardContent className="px-3 sm:px-6 pb-3 sm:pb-6">
                <div className="max-h-36 sm:max-h-48 overflow-y-auto space-y-1">
                  {decodeLog.map((entry, i) => (
                    <div key={i} className="flex items-start gap-2 text-xs font-mono">
                      <span className={
                        entry.type === 'success' ? 'text-accent' :
                        entry.type === 'error' ? 'text-destructive' : 'text-yellow-600'
                      }>
                        {entry.type === 'success' ? '✓' : entry.type === 'error' ? '✗' : '⚠'}
                      </span>
                      <span className="text-muted-foreground break-all">{entry.msg}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}