import React from 'react';
import { Link } from 'react-router-dom';
import { Upload, ScanLine, QrCode, Shield, Wifi, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import StandaloneDownload from '@/pages/StandaloneDownload';

const features = [
  { icon: Wifi, title: 'Air-Gapped', desc: 'Transfer files across physically isolated networks using only QR codes' },
  { icon: Shield, title: 'Integrity Verified', desc: 'CRC32 checksums on every chunk and the full file ensure zero corruption' },
  { icon: Zap, title: 'Fully Offline', desc: 'Everything runs client-side in your browser — no server, no uploads' },
];

export default function Home() {
  return (
    <div className="space-y-8 sm:space-y-12">
      {/* Hero */}
      <section className="text-center pt-6 sm:pt-10 pb-2 sm:pb-4">
        <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-primary/5 border border-primary/20 flex items-center justify-center mx-auto mb-4 sm:mb-6 glow-cyan">
          <QrCode className="w-8 h-8 sm:w-10 sm:h-10 text-primary" />
        </div>
        <h1 className="text-2xl sm:text-4xl font-display font-bold tracking-widest uppercase text-primary glow-text-cyan">
          QR Fragment
        </h1>
        <p className="font-mono text-[10px] sm:text-xs tracking-wider uppercase text-muted-foreground mt-1.5 sm:mt-2">
          // Classified Transfer System
        </p>
        <p className="text-muted-foreground mt-3 sm:mt-4 max-w-lg mx-auto text-xs sm:text-sm leading-relaxed px-2">
          Transfer any file across air-gapped systems by fragmenting it into a sequence of QR codes —
          then reconstruct it on the other side.
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-2 sm:gap-3 mt-6 sm:mt-8 px-4">
          <Link to="/encode" className="w-full sm:w-auto">
            <Button size="lg" className="gap-2 font-mono text-xs tracking-wider uppercase glow-cyan w-full sm:w-auto">
              <Upload className="w-4 h-4" /> Encode File
            </Button>
          </Link>
          <Link to="/decode" className="w-full sm:w-auto">
            <Button size="lg" variant="outline" className="gap-2 font-mono text-xs tracking-wider uppercase border-primary/30 text-primary hover:bg-primary/10 w-full sm:w-auto">
              <ScanLine className="w-4 h-4" /> Decode / Reconstruct
            </Button>
          </Link>
        </div>
      </section>

      {/* Features */}
      <section className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4">
        {features.map(({ icon: Icon, title, desc }) => (
          <div key={title} className="rounded-xl border border-border/60 bg-card p-4 sm:p-5 space-y-2 sm:space-y-3 hover:border-primary/20 transition-colors">
            <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-primary/5 border border-primary/20 flex items-center justify-center">
              <Icon className="w-4 h-4 text-primary" />
            </div>
            <h3 className="font-display text-xs font-semibold tracking-wider uppercase text-foreground">{title}</h3>
            <p className="text-xs text-muted-foreground leading-relaxed">{desc}</p>
          </div>
        ))}
      </section>

      {/* Standalone download */}
      <section>
        <StandaloneDownload />
      </section>

      {/* How it works */}
      <section className="rounded-xl border border-border/60 bg-card p-4 sm:p-6">
        <h2 className="font-display text-sm font-semibold tracking-wider uppercase text-primary mb-4 sm:mb-5">◈ How It Works</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6">
          {[
            { step: '01', title: 'Select a File', desc: 'Pick any file from your device. It never leaves your browser.' },
            { step: '02', title: 'Generate QR Codes', desc: 'The file is split into chunks, each encoded as a QR code with integrity metadata.' },
            { step: '03', title: 'Scan & Reconstruct', desc: 'On the receiving device, scan or import the QR images to reassemble the original file.' },
          ].map((s) => (
            <div key={s.step} className="flex gap-3 sm:gap-4">
              <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-primary/5 border border-primary/20 flex items-center justify-center font-mono text-xs font-bold text-primary shrink-0 mt-0.5">
                {s.step}
              </div>
              <div>
                <p className="font-mono text-xs font-semibold tracking-wide uppercase text-foreground">{s.title}</p>
                <p className="text-xs text-muted-foreground mt-1 sm:mt-1.5 leading-relaxed">{s.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}