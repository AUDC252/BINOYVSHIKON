import React, { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Download, Loader2, FileCode, Shield, Cpu, Palette, ExternalLink, Smartphone } from 'lucide-react';
import { buildStandaloneHTML } from '@/lib/standalone/build';

export default function StandaloneDownload() {
  const [generating, setGenerating] = useState(false);
  const [openingIOS, setOpeningIOS] = useState(false);

  const handleDownload = useCallback(() => {
    setGenerating(true);
    const html = buildStandaloneHTML();
    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'qr-fragment-standalone.html';
    a.click();
    URL.revokeObjectURL(url);
    setTimeout(() => setGenerating(false), 500);
  }, []);

  const handleOpenIOS = useCallback(() => {
    setOpeningIOS(true);
    const html = buildStandaloneHTML();
    // Open a new window and write the HTML directly — works on iOS Safari
    const w = window.open('', '_blank');
    if (w) {
      w.document.open();
      w.document.write(html);
      w.document.close();
    }
    setTimeout(() => setOpeningIOS(false), 1000);
  }, []);

  return (
    <Card className="border-primary/20">
      <CardContent className="pt-6 space-y-4">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0">
            <FileCode className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h3 className="font-display text-xs font-semibold tracking-wider uppercase">Standalone Tool</h3>
            <p className="text-xs text-muted-foreground mt-1 leading-relaxed">
              Single HTML file with all features: QR Encode/Decode, ColorGrid Encode/Decode, Camera Scanner, and Stream Viewer. Works completely offline.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          <span className="inline-flex items-center gap-1 text-[10px] font-mono px-2 py-0.5 rounded bg-accent/10 text-accent border border-accent/20">
            <Shield className="w-3 h-3" /> Encryption
          </span>
          <span className="inline-flex items-center gap-1 text-[10px] font-mono px-2 py-0.5 rounded bg-primary/10 text-primary border border-primary/20">
            <Cpu className="w-3 h-3" /> Camera Scanner
          </span>
          <span className="inline-flex items-center gap-1 text-[10px] font-mono px-2 py-0.5 rounded bg-chart-3/10 text-chart-3 border border-chart-3/20">
            <Palette className="w-3 h-3" /> ColorGrid
          </span>
        </div>

        <div className="space-y-2">
          <Button onClick={handleDownload} disabled={generating} className="w-full gap-2 font-mono text-xs tracking-wider uppercase">
            {generating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
            {generating ? 'Generating\u2026' : 'Download HTML File'}
          </Button>

          <Button onClick={handleOpenIOS} disabled={openingIOS} variant="outline" className="w-full gap-2 font-mono text-xs tracking-wider uppercase border-primary/30 text-primary hover:bg-primary/10">
            {openingIOS ? <Loader2 className="w-4 h-4 animate-spin" /> : <Smartphone className="w-4 h-4" />}
            {openingIOS ? 'Opening\u2026' : 'Open in Browser (iOS)'}
          </Button>
          <p className="text-[10px] text-muted-foreground text-center leading-relaxed">
            iOS: Use "Open in Browser" to launch directly in Safari without downloading. Then use Share → Add to Home Screen for app-like access.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}