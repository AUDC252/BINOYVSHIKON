import React from 'react';
import { Palette } from 'lucide-react';
import ColorGridDecoder from '@/components/colorgrid/ColorGridDecoder';
import { getCapacityInfo } from '@/lib/colorgrid';
import { formatBytes } from '@/lib/qr-engine';

export default function PrintDecode() {
  const capacity = getCapacityInfo();

  return (
    <div className="space-y-4 sm:space-y-6">
      <div>
        <h1 className="text-xl sm:text-2xl font-bold flex items-center gap-2">
          <Palette className="w-5 h-5 sm:w-6 sm:h-6 text-accent" />
          Color Grid Decode
        </h1>
        <p className="text-xs sm:text-sm text-muted-foreground mt-1">
          Scan or upload ColorGrid pages to reconstruct the original file.
          Each page holds up to <strong className="text-foreground">{formatBytes(capacity.netCapacityPerPage)}</strong>.
        </p>
      </div>

      <ColorGridDecoder />
    </div>
  );
}