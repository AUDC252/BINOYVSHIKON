import React, { useState, useCallback } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, QrCode, List } from 'lucide-react';
import FileUploader from '@/components/encode/FileUploader';
import ChunkConfig from '@/components/encode/ChunkConfig';
import PasswordInput from '@/components/encode/PasswordInput';
import TransferSummary from '@/components/encode/TransferSummary';
import QRViewer from '@/components/qr/QRViewer';
import QRGrid from '@/components/qr/QRGrid';
import { fragmentFile, generateAllQRDataUrls, createEncodeSession, formatBytes, calculateMaxChunkBytes } from '@/lib/qr-engine';
import JSZip from 'jszip';

export default function Encode() {
  const [file, setFile] = useState(null);
  const [config, setConfig] = useState({ chunkSize: 400, errorCorrection: 'M' });
  const [password, setPassword] = useState('');
  const [session, setSession] = useState(null);
  const [qrCodes, setQrCodes] = useState(null);
  const [generating, setGenerating] = useState(false);
  const [viewTab, setViewTab] = useState('slideshow');

  const handleGenerate = useCallback(async () => {
    if (!file) return;
    setGenerating(true);

    const arrayBuffer = await file.arrayBuffer();
    try {
      const maxSafe = calculateMaxChunkBytes(file.name, config.errorCorrection, !!password);
      const safeChunkSize = Math.min(config.chunkSize, maxSafe);
      
      const fragResult = fragmentFile(arrayBuffer, file.name, file.type, {
        chunkSize: safeChunkSize,
        errorCorrection: config.errorCorrection,
        password: password || null,
      });

      const sess = createEncodeSession(fragResult);
      setSession(sess);

      const codes = await generateAllQRDataUrls(fragResult.chunks, {
        errorCorrectionLevel: config.errorCorrection,
        width: 1200,
      });
      setQrCodes(codes);
    } catch (err) {
      const { toast } = await import('sonner');
      toast.error(err.message);
    }
    setGenerating(false);
  }, [file, config, password]);

  const handleClear = () => {
    setFile(null);
    setSession(null);
    setQrCodes(null);
  };

  const handleExportAll = async () => {
    if (!qrCodes || !session) return;
    const zip = new JSZip();
    const folder = zip.folder(session.fileName.replace(/\.[^.]+$/, ''));
    // Save QR images only — no JSON fallback
    for (let i = 0; i < qrCodes.length; i++) {
      const dataUrl = qrCodes[i].dataUrl;
      const base64 = dataUrl.split(',')[1];
      folder.file(`chunk_${String(i + 1).padStart(3, '0')}.png`, base64, { base64: true });
    }
    const blob = await zip.generateAsync({ type: 'blob', mimeType: 'application/zip' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `${session.fileName.replace(/\.[^.]+$/, '')}_qr.zip`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(a.href);
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      <div>
        <h1 className="text-xl sm:text-2xl font-bold">Encode File</h1>
        <p className="text-xs sm:text-sm text-muted-foreground mt-1">
          Fragment a file into QR codes for air-gapped transfer.
        </p>
      </div>

      <FileUploader file={file} onFileSelect={setFile} onClear={handleClear} />

      {file && !qrCodes && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
          <div className="rounded-xl border bg-card p-4 sm:p-5">
            <h2 className="font-semibold text-sm mb-3 sm:mb-4">Chunk Configuration</h2>
            <ChunkConfig config={config} onChange={setConfig} fileName={file.name} encrypted={!!password} />
            <div className="mt-3 sm:mt-4 pt-3 sm:pt-4 border-t">
              <PasswordInput password={password} onChange={setPassword} />
            </div>
          </div>
          <div className="rounded-xl border bg-card p-4 sm:p-5 flex flex-col">
            <h2 className="font-semibold text-sm mb-3">Ready to Encode</h2>
            <div className="text-xs text-muted-foreground space-y-1 flex-1">
              <p>File: <strong className="break-all">{file.name}</strong></p>
              <p>Size: <strong>{formatBytes(file.size)}</strong></p>
              <p>Est. chunks: <strong>{Math.ceil(file.size / config.chunkSize)}</strong></p>
            </div>
            <Button onClick={handleGenerate} disabled={generating} className="mt-4 gap-2 w-full">
              {generating ? <Loader2 className="w-4 h-4 animate-spin" /> : <QrCode className="w-4 h-4" />}
              {generating ? 'Generating…' : 'Generate QR Codes'}
            </Button>
          </div>
        </div>
      )}

      {qrCodes && session && (
        <div className="space-y-4 sm:space-y-6">
          <TransferSummary session={session} />

          <Tabs value={viewTab} onValueChange={setViewTab}>
            <div className="flex items-center gap-2 sm:gap-3 mb-3 sm:mb-4">
              <TabsList>
                <TabsTrigger value="slideshow" className="gap-1.5 text-xs">
                  <QrCode className="w-3.5 h-3.5" /> Slideshow
                </TabsTrigger>
                <TabsTrigger value="grid" className="gap-1.5 text-xs">
                  <List className="w-3.5 h-3.5" /> Grid
                </TabsTrigger>
              </TabsList>
              <Badge variant="secondary" className="text-xs">
                {qrCodes.length} QR codes
              </Badge>
            </div>

            <TabsContent value="slideshow">
              <QRViewer
                qrCodes={qrCodes}
                chunks={session.chunks}
                onExportAll={handleExportAll}
              />
            </TabsContent>

            <TabsContent value="grid">
              <QRGrid
                qrCodes={qrCodes}
                onSelect={(idx) => { setViewTab('slideshow'); }}
              />
            </TabsContent>
          </Tabs>
        </div>
      )}
    </div>
  );
}