import React, { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Download, Loader2 } from 'lucide-react';
import { generateLandingHTML } from '@/lib/landing-html';

export default function LandingPage() {
  const [generating, setGenerating] = useState(false);

  const handleDownload = useCallback(() => {
    setGenerating(true);
    const html = generateLandingHTML();
    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'qr-fragment-landing.html';
    a.click();
    URL.revokeObjectURL(url);
    setTimeout(() => setGenerating(false), 500);
  }, []);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl sm:text-2xl font-bold">Landing Page Generator</h1>
        <p className="text-xs sm:text-sm text-muted-foreground mt-1">
          Download a stunning standalone landing page HTML file that showcases QR Fragment.
        </p>
      </div>

      <div className="rounded-xl border bg-card p-6 space-y-4">
        <p className="text-sm text-muted-foreground leading-relaxed">
          This generates a fully self-contained HTML file with animations, competitive analysis,
          and technical details about QR Fragment's unique capabilities.
        </p>
        <Button onClick={handleDownload} disabled={generating} className="w-full gap-2">
          {generating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
          {generating ? 'Generating…' : 'Download Landing Page HTML'}
        </Button>
      </div>

      {/* Preview iframe */}
      <div className="rounded-xl border overflow-hidden" style={{ height: '70vh' }}>
        <iframe
          srcDoc={generateLandingHTML()}
          className="w-full h-full border-0"
          title="Landing Page Preview"
        />
      </div>
    </div>
  );
}