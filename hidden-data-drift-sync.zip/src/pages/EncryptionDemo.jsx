import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Shield, Play, RotateCcw, Lock, Zap, Eye, EyeOff, Shuffle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';

// ── Xoshiro128** PRNG (same as real encryption) ──
function xoshiro128ss(seed) {
  let s = [seed >>> 0, (seed * 1597334677) >>> 0, (seed * 2246822519) >>> 0, (seed * 3266489917) >>> 0];
  return function() {
    const r = Math.imul(s[1] * 5, 7) >>> 0;
    const t = s[1] << 9;
    s[2] ^= s[0]; s[3] ^= s[1]; s[1] ^= s[2]; s[0] ^= s[3];
    s[2] ^= t; s[3] = (s[3] << 11) | (s[3] >>> 21);
    return r;
  };
}

function fnv1a(str) {
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return h >>> 0;
}

function xorEncrypt(data, password, chunkIdx) {
  const seed = fnv1a(password + ':' + chunkIdx);
  const rng = xoshiro128ss(seed);
  const out = new Uint8Array(data.length);
  for (let i = 0; i < data.length; i++) {
    out[i] = data[i] ^ (rng() & 0xFF);
  }
  return out;
}

// ── Visual helpers ──
function bytesToHex(bytes, maxLen = 32) {
  let hex = '';
  const len = Math.min(bytes.length, maxLen);
  for (let i = 0; i < len; i++) hex += bytes[i].toString(16).padStart(2, '0') + ' ';
  if (bytes.length > maxLen) hex += '...';
  return hex.trim();
}

function bytesToColorBlocks(bytes, maxLen = 64) {
  const blocks = [];
  const len = Math.min(bytes.length, maxLen);
  for (let i = 0; i < len; i++) {
    const v = bytes[i];
    const r = (v & 0xE0);
    const g = ((v & 0x1C) << 3);
    const b = ((v & 0x03) << 6);
    blocks.push({ byte: v, color: `rgb(${r},${g},${b})` });
  }
  return blocks;
}

// ── Brute force time estimation ──
function estimateBruteForce(passwordLength, charset) {
  const charsetSizes = { lowercase: 26, alphanumeric: 62, full: 95 };
  const size = charsetSizes[charset] || 62;
  const combinations = Math.pow(size, passwordLength);
  
  // Assume attacker tries 1 billion (10^9) passwords per second (very generous — real is much slower)
  const attemptsPerSecond = 1e9;
  const seconds = combinations / attemptsPerSecond;
  
  const minutes = seconds / 60;
  const hours = minutes / 60;
  const days = hours / 24;
  const years = days / 365.25;
  const millennia = years / 1000;
  const universeAges = years / 13.8e9;
  
  return { combinations, seconds, minutes, hours, days, years, millennia, universeAges, attemptsPerSecond };
}

function formatTime(est) {
  if (est.universeAges > 1) return { value: est.universeAges.toExponential(1), unit: 'גילאי יקום', emoji: '🌌', level: 'impossible' };
  if (est.millennia > 1) return { value: est.millennia.toExponential(1), unit: 'אלפי שנים', emoji: '⏳', level: 'impossible' };
  if (est.years > 100) return { value: Math.round(est.years).toLocaleString(), unit: 'שנים', emoji: '🏛️', level: 'impossible' };
  if (est.years > 1) return { value: est.years.toFixed(1), unit: 'שנים', emoji: '📅', level: 'hard' };
  if (est.days > 1) return { value: Math.round(est.days).toLocaleString(), unit: 'ימים', emoji: '📆', level: 'medium' };
  if (est.hours > 1) return { value: Math.round(est.hours).toLocaleString(), unit: 'שעות', emoji: '⏰', level: 'medium' };
  if (est.minutes > 1) return { value: Math.round(est.minutes).toLocaleString(), unit: 'דקות', emoji: '⚡', level: 'weak' };
  return { value: Math.round(est.seconds).toLocaleString(), unit: 'שניות', emoji: '💨', level: 'weak' };
}

// ── Brute Force Simulator ──
function BruteForceSimulator({ realPassword }) {
  const [running, setRunning] = useState(false);
  const [attempts, setAttempts] = useState(0);
  const [currentGuess, setCurrentGuess] = useState('');
  const [found, setFound] = useState(false);
  const [speed, setSpeed] = useState(0);
  const intervalRef = useRef(null);
  const startTimeRef = useRef(null);
  const attemptsRef = useRef(0);
  
  const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*';
  
  const generateGuess = useCallback((len) => {
    let g = '';
    for (let i = 0; i < len; i++) g += chars[Math.floor(Math.random() * chars.length)];
    return g;
  }, []);
  
  const start = () => {
    setRunning(true);
    setFound(false);
    setAttempts(0);
    attemptsRef.current = 0;
    startTimeRef.current = Date.now();
    
    intervalRef.current = setInterval(() => {
      const batchSize = 137; // simulate batch
      attemptsRef.current += batchSize;
      const guess = generateGuess(realPassword.length || 6);
      setCurrentGuess(guess);
      setAttempts(attemptsRef.current);
      
      const elapsed = (Date.now() - startTimeRef.current) / 1000;
      if (elapsed > 0) setSpeed(Math.round(attemptsRef.current / elapsed));
    }, 50);
  };
  
  const stop = () => {
    setRunning(false);
    if (intervalRef.current) clearInterval(intervalRef.current);
  };
  
  const reset = () => {
    stop();
    setAttempts(0);
    setCurrentGuess('');
    setFound(false);
    setSpeed(0);
  };
  
  useEffect(() => () => { if (intervalRef.current) clearInterval(intervalRef.current); }, []);
  
  const est = realPassword ? estimateBruteForce(realPassword.length, 'full') : null;
  const progressPct = est ? Math.min((attempts / est.combinations) * 100, 100) : 0;
  
  return (
    <div className="rounded-xl border bg-card p-4 sm:p-5 space-y-4">
      <div className="flex items-center gap-2">
        <Zap className="w-5 h-5 text-amber-400" />
        <h3 className="font-bold text-sm">סימולציית Brute-Force</h3>
        <Badge variant="secondary" className="text-[10px] mr-auto">LIVE</Badge>
      </div>
      
      <p className="text-xs text-muted-foreground">
        מדמה תוקף שמנסה לנחש את הסיסמה שלך. המהירות כאן (~2,700/שנייה בדפדפן) <strong className="text-foreground">איטית פי 370,000</strong> ממחשב מתקדם.
      </p>
      
      <div className="flex flex-wrap gap-2">
        <Button size="sm" onClick={start} disabled={running || !realPassword} className="gap-1.5">
          <Play className="w-3.5 h-3.5" /> התחל מתקפה
        </Button>
        <Button size="sm" variant="outline" onClick={stop} disabled={!running} className="gap-1.5">
          ◼ עצור
        </Button>
        <Button size="sm" variant="ghost" onClick={reset} className="gap-1.5">
          <RotateCcw className="w-3.5 h-3.5" /> אפס
        </Button>
      </div>
      
      {(running || attempts > 0) && (
        <div className="space-y-3">
          <div className="rounded-lg bg-background border p-3 space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-muted-foreground">ניסיון נוכחי:</span>
              <span className="font-mono text-destructive font-bold tracking-wider">{currentGuess}</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-muted-foreground">סה"כ ניסיונות:</span>
              <span className="font-mono text-foreground font-bold">{attempts.toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-muted-foreground">מהירות:</span>
              <span className="font-mono text-foreground">{speed.toLocaleString()}/שנייה</span>
            </div>
            {est && (
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">שנותר לנסות:</span>
                <span className="font-mono text-amber-400">{est.combinations.toExponential(2)}</span>
              </div>
            )}
          </div>
          
          <div>
            <div className="flex justify-between text-[10px] text-muted-foreground mb-1">
              <span>התקדמות המתקפה</span>
              <span>{progressPct < 0.0001 ? '< 0.0001' : progressPct.toFixed(4)}%</span>
            </div>
            <Progress value={Math.max(progressPct, 0.01)} className="h-2" />
          </div>
          
          {est && (
            <div className="rounded-lg bg-destructive/5 border border-destructive/20 p-3">
              <p className="text-xs text-center">
                <span className="text-muted-foreground">בקצב הזה, הסיסמה תיפרץ בעוד: </span>
                <br />
                <strong className="text-lg text-destructive font-mono">
                  {(() => {
                    const secsLeft = (est.combinations - attempts) / (speed || 1);
                    const y = secsLeft / (365.25 * 86400);
                    if (y > 1e15) return y.toExponential(1) + ' שנים';
                    if (y > 1e9) return (y / 1e9).toFixed(1) + ' מיליארד שנים';
                    if (y > 1e6) return (y / 1e6).toFixed(1) + ' מיליון שנים';
                    if (y > 1000) return Math.round(y).toLocaleString() + ' שנים';
                    if (y > 1) return y.toFixed(1) + ' שנים';
                    const d = secsLeft / 86400;
                    if (d > 1) return Math.round(d).toLocaleString() + ' ימים';
                    return Math.round(secsLeft).toLocaleString() + ' שניות';
                  })()}
                </strong>
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ── Main Page ──
export default function EncryptionDemo() {
  const [sampleText, setSampleText] = useState('שלום עולם! זהו טקסט סודי ביותר 🔒');
  const [password, setPassword] = useState('MyP@ss123');
  const [showPassword, setShowPassword] = useState(true);
  const [charset, setCharset] = useState('full');
  
  const rawBytes = new TextEncoder().encode(sampleText);
  const encryptedBytes = password ? xorEncrypt(rawBytes, password, 0) : rawBytes;
  
  const rawBlocks = bytesToColorBlocks(rawBytes, 80);
  const encBlocks = bytesToColorBlocks(encryptedBytes, 80);
  
  const est = estimateBruteForce(password.length, charset);
  const ft = formatTime(est);
  
  const levelColors = {
    impossible: 'text-accent',
    hard: 'text-amber-400',
    medium: 'text-yellow-500',
    weak: 'text-destructive',
  };

  // Shuffling visual
  const chunkCount = 20;
  const originalOrder = Array.from({ length: chunkCount }, (_, i) => i);
  const shuffledOrder = [...originalOrder];
  if (password) {
    const rng = xoshiro128ss(fnv1a(password + ':shuffle'));
    for (let i = shuffledOrder.length - 1; i > 0; i--) {
      const j = rng() % (i + 1);
      [shuffledOrder[i], shuffledOrder[j]] = [shuffledOrder[j], shuffledOrder[i]];
    }
  }

  return (
    <div className="space-y-5 sm:space-y-6">
      <div>
        <h1 className="text-xl sm:text-2xl font-bold flex items-center gap-2">
          <Shield className="w-5 h-5 sm:w-6 sm:h-6 text-primary" />
          הדמיה ויזואלית — הצפנה
        </h1>
        <p className="text-xs sm:text-sm text-muted-foreground mt-1">
          ראה בזמן אמת מה קורה לנתונים שלך, כמה זמן ייקח לפרוץ, וסימולציה חיה של מתקפה.
        </p>
      </div>

      {/* ── INPUT ── */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="rounded-xl border bg-card p-4 space-y-3">
          <h3 className="text-sm font-semibold flex items-center gap-2">
            <Eye className="w-4 h-4 text-primary" /> טקסט לדוגמה
          </h3>
          <Input value={sampleText} onChange={(e) => setSampleText(e.target.value)} className="font-mono text-sm" />
          <p className="text-[10px] text-muted-foreground">{rawBytes.length} בתים</p>
        </div>
        <div className="rounded-xl border bg-card p-4 space-y-3">
          <h3 className="text-sm font-semibold flex items-center gap-2">
            <Lock className="w-4 h-4 text-amber-400" /> סיסמה
          </h3>
          <div className="relative">
            <Input
              type={showPassword ? 'text' : 'password'}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="font-mono text-sm pr-10"
            />
            <button onClick={() => setShowPassword(!showPassword)} className="absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
          <div className="flex gap-2 flex-wrap">
            {[['lowercase', 'a-z', '26'], ['alphanumeric', 'a-Z 0-9', '62'], ['full', 'הכל', '95']].map(([key, label, size]) => (
              <button key={key} onClick={() => setCharset(key)}
                className={`text-[10px] font-mono px-2 py-1 rounded border transition-all ${charset === key ? 'border-primary bg-primary/10 text-primary' : 'border-border text-muted-foreground hover:text-foreground'}`}>
                {label} ({size})
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* ── XOR EXPLAINER ── */}
      <div className="rounded-xl border border-primary/20 bg-primary/5 p-4 sm:p-5 space-y-4">
        <h3 className="text-sm font-semibold">🔑 מה זה XOR? בשפה הכי פשוטה שיש</h3>
        <div className="space-y-3 text-sm text-muted-foreground">
          <p>
            דמיין שיש לך <strong className="text-foreground">כספת עם קוד</strong>. ה-XOR הוא כמו פעולה שמערבלת את המספר שלך עם מפתח סודי:
          </p>
          <div className="rounded-lg bg-background border p-4 font-mono text-xs space-y-2">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-primary">הנתון שלך:</span>
              <span className="text-foreground font-bold">42</span>
              <span className="text-muted-foreground">→ בבינארי:</span>
              <span className="text-primary">00101010</span>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-amber-400">מפתח אקראי:</span>
              <span className="text-foreground font-bold">99</span>
              <span className="text-muted-foreground">→ בבינארי:</span>
              <span className="text-amber-400">01100011</span>
            </div>
            <div className="border-t border-dashed border-border pt-2 flex items-center gap-2 flex-wrap">
              <span className="text-destructive">תוצאה (XOR):</span>
              <span className="text-foreground font-bold">73</span>
              <span className="text-muted-foreground">→ בבינארי:</span>
              <span className="text-destructive">01001001</span>
            </div>
          </div>
          <p>
            <strong className="text-foreground">הכלל פשוט:</strong> כל ביט (0 או 1) עובר ערבוב — אם שני הביטים שווים → 0, אם שונים → 1.
            בלי המפתח, אי אפשר לחזור לנתון המקורי. <strong className="text-foreground">עם המפתח — אותה פעולה בדיוק מחזירה את המקור.</strong>
          </p>
          <p>
            <strong className="text-foreground">חשוב:</strong> המפתח הוא <strong className="text-primary">לא</strong> הסיסמה עצמה.
            הסיסמה שלך מייצרת <strong className="text-foreground">מחולל מספרים אקראיים</strong> (Xoshiro128**), שמייצר מפתח שונה לכל בייט.
            אז אפילו אות חוזרת בטקסט — מוצפנת אחרת בכל פעם.
          </p>
        </div>
      </div>

      {/* ── VISUAL: ORIGINAL vs ENCRYPTED ── */}
      <div className="rounded-xl border bg-card p-4 sm:p-5 space-y-4">
        <h3 className="text-sm font-semibold">🎨 ויזואליזציה: מקור ← מוצפן</h3>
        <p className="text-xs text-muted-foreground">
          כל בריבוע = בייט אחד מהנתונים, צבוע לפי הערך שלו.
          <strong className="text-foreground"> הצבעים הם רק דרך להראות לך את השינוי</strong> — שים לב איך הדפוס המסודר הופך לרעש אקראי מוחלט.
        </p>
        
        <div className="space-y-3">
          <div>
            <p className="text-[10px] font-mono text-muted-foreground mb-1.5">נתונים מקוריים (יש דפוס — צבעים דומים חוזרים):</p>
            <div className="flex flex-wrap gap-px">
              {rawBlocks.map((b, i) => (
                <div key={i} className="w-4 h-4 sm:w-5 sm:h-5 rounded-sm" style={{ background: b.color }} title={`0x${b.byte.toString(16).padStart(2, '0')}`} />
              ))}
            </div>
          </div>
          
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Lock className="w-3.5 h-3.5 text-primary" />
            <span className="font-mono">XOR עם מפתח שנגזר מ-"{password}"</span>
            <div className="flex-1 border-t border-dashed border-primary/30" />
          </div>
          
          <div>
            <p className="text-[10px] font-mono text-muted-foreground mb-1.5">אחרי הצפנה (רעש אקראי — אין שום דפוס):</p>
            <div className="flex flex-wrap gap-px">
              {encBlocks.map((b, i) => (
                <div key={i} className="w-4 h-4 sm:w-5 sm:h-5 rounded-sm" style={{ background: b.color }} title={`0x${b.byte.toString(16).padStart(2, '0')}`} />
              ))}
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[10px] font-mono">
          <div className="rounded-lg bg-background border p-2.5">
            <p className="text-muted-foreground mb-1">HEX מקורי:</p>
            <p className="break-all text-foreground">{bytesToHex(rawBytes)}</p>
          </div>
          <div className="rounded-lg bg-background border p-2.5">
            <p className="text-muted-foreground mb-1">HEX מוצפן:</p>
            <p className="break-all text-destructive">{bytesToHex(encryptedBytes)}</p>
          </div>
        </div>
      </div>

      {/* ── VISUAL: CHUNK SHUFFLING ── */}
      <div className="rounded-xl border bg-card p-4 sm:p-5 space-y-4">
        <h3 className="text-sm font-semibold flex items-center gap-2">
          <Shuffle className="w-4 h-4 text-green-400" /> שכבה 2: ערבוב סדר החתיכות
        </h3>
        <p className="text-xs text-muted-foreground">
          אחרי ההצפנה, סדר החתיכות מעורבל. גם אם מישהו פיענח את ההצפנה — הוא לא יודע באיזה סדר לשחזר.
        </p>
        
        <div className="space-y-2">
          <p className="text-[10px] font-mono text-muted-foreground">סדר מקורי:</p>
          <div className="flex flex-wrap gap-1">
            {originalOrder.map(i => (
              <div key={i} className="w-8 h-8 rounded bg-primary/15 border border-primary/30 flex items-center justify-center text-[10px] font-mono text-primary font-bold">
                {i}
              </div>
            ))}
          </div>
          
          <div className="flex items-center gap-2 text-xs text-muted-foreground py-1">
            <Shuffle className="w-3.5 h-3.5 text-green-400" />
            <span className="font-mono">Shuffle("{password}")</span>
            <div className="flex-1 border-t border-dashed border-green-400/30" />
          </div>
          
          <p className="text-[10px] font-mono text-muted-foreground">סדר מעורבל:</p>
          <div className="flex flex-wrap gap-1">
            {shuffledOrder.map((val, i) => (
              <div key={i} className="w-8 h-8 rounded bg-green-500/10 border border-green-500/30 flex items-center justify-center text-[10px] font-mono text-green-400 font-bold">
                {val}
              </div>
            ))}
          </div>
          
          <p className="text-[10px] text-muted-foreground mt-1">
            Permutations אפשריות עבור {chunkCount} חתיכות: <strong className="text-foreground font-mono">{chunkCount}! = {(() => { let f = 1n; for (let i = 2n; i <= BigInt(chunkCount); i++) f *= i; return f.toLocaleString(); })()}</strong>
          </p>
        </div>
      </div>

      {/* ── DICTIONARY ATTACK WARNING ── */}
      <div className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-4 sm:p-5 space-y-3">
        <h3 className="text-sm font-semibold flex items-center gap-2 text-amber-400">⚠️ מתקפת מילון — למה "12345678910" זו סיסמה גרועה</h3>
        <div className="text-xs text-muted-foreground space-y-2">
          <p>
            חשוב להבין: <strong className="text-foreground">יש שני סוגי מתקפות.</strong>
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="rounded-lg bg-background border p-3 space-y-1.5">
              <p className="font-semibold text-foreground">🔨 Brute-Force (כוח גס)</p>
              <p>מנסה <strong className="text-foreground">כל צירוף אפשרי</strong> לפי הסדר: a, b, c... aa, ab... המחשב לא "יודע" שהסיסמה שלך קלה — הוא פשוט מנסה הכל.</p>
              <p className="text-accent">← כאן 11 תווים = מיליארדי שנים ✓</p>
            </div>
            <div className="rounded-lg bg-background border border-amber-500/20 p-3 space-y-1.5">
              <p className="font-semibold text-amber-400">📖 Dictionary Attack (מתקפת מילון)</p>
              <p>מנסה <strong className="text-foreground">סיסמאות נפוצות קודם</strong> מתוך רשימה: password, 123456, 12345678910, qwerty, iloveyou...</p>
              <p className="text-destructive">← כאן "12345678910" תיפרץ בשניות!</p>
            </div>
          </div>
          <div className="rounded-lg bg-destructive/5 border border-destructive/20 p-3">
            <p className="font-semibold text-destructive mb-1">⛔ סיסמאות שיפרצו בשניות:</p>
            <p className="font-mono text-[10px] text-muted-foreground">123456, password, 12345678910, qwerty, abc123, שלום, admin, iloveyou, 000000</p>
          </div>
          <div className="rounded-lg bg-accent/5 border border-accent/20 p-3">
            <p className="font-semibold text-accent mb-1">✅ סיסמאות שלא יפרצו:</p>
            <p className="font-mono text-[10px] text-muted-foreground">k9$mPx2!vQ, ח0פש-גד0ל!, My-D0g-Ate-7-Pizzas</p>
            <p className="mt-1">הכלל: <strong className="text-foreground">אם אתה יכול לנחש את הסיסמה — גם מחשב יכול. אם היא אקראית/יחודית — רק brute-force עובד.</strong></p>
          </div>
        </div>
      </div>

      {/* ── TIME ESTIMATE ── */}
      <div className="rounded-xl border bg-card p-4 sm:p-5 space-y-4">
        <h3 className="text-sm font-semibold">⏱️ כמה זמן לפרוץ? (Brute-Force בלבד)</h3>
        <p className="text-xs text-muted-foreground">
          הנחה: תוקף עם מחשב שמנסה <strong className="text-foreground font-mono">1,000,000,000</strong> סיסמאות בשנייה.
          <strong className="text-amber-400"> הזמנים הבאים רלוונטיים רק לסיסמאות אקראיות ויחודיות!</strong> סיסמאות נפוצות (123456, password) ייפרצו בשניות בכל אורך.
        </p>
        
        <div className="rounded-xl bg-background border p-5 text-center space-y-3">
          <div className="text-4xl sm:text-5xl">{ft.emoji}</div>
          <div>
            <span className={`text-3xl sm:text-4xl font-mono font-black ${levelColors[ft.level]}`}>{ft.value}</span>
            <span className="text-lg text-muted-foreground mr-2"> {ft.unit}</span>
          </div>
          <p className="text-xs text-muted-foreground">
            סיסמה אקראית באורך <strong className="text-foreground">{password.length}</strong> תווים ×{' '}
            <strong className="text-foreground">{charset === 'lowercase' ? '26' : charset === 'alphanumeric' ? '62' : '95'}</strong> תווים אפשריים ={' '}
            <strong className="text-foreground font-mono">{est.combinations.toExponential(2)}</strong> צירופים
          </p>
        </div>

        {/* Password length comparison */}
        <div className="space-y-2">
          <p className="text-xs font-semibold">השוואה לפי אורך סיסמה אקראית (מיליארד ניסיונות/שנייה):</p>
          <div className="space-y-1.5">
            {[4, 6, 8, 10, 12, 16, 20].map(len => {
              const e = estimateBruteForce(len, charset);
              const f = formatTime(e);
              const isActive = len === password.length;
              return (
                <div key={len} className={`flex items-center gap-3 text-xs rounded-lg px-3 py-2 transition-all ${isActive ? 'bg-primary/10 border border-primary/30' : 'bg-background border border-transparent'}`}>
                  <span className="font-mono w-8 text-muted-foreground">{len}</span>
                  <div className="flex-1">
                    <div className="h-2 rounded-full bg-muted overflow-hidden">
                      <div className="h-full rounded-full transition-all" style={{
                        width: `${Math.min(100, Math.max(2, Math.log10(e.seconds + 1) / 30 * 100))}%`,
                        background: f.level === 'impossible' ? 'hsl(var(--accent))' : f.level === 'hard' ? '#f59e0b' : f.level === 'medium' ? '#eab308' : 'hsl(var(--destructive))'
                      }} />
                    </div>
                  </div>
                  <span className={`font-mono min-w-[120px] text-left ${levelColors[f.level]}`}>
                    {f.value} {f.unit}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* ── BRUTE FORCE SIMULATOR ── */}
      <BruteForceSimulator realPassword={password} />
      
      {/* ── CHECKSUM POISONING ── */}
      <div className="rounded-xl border bg-card p-4 sm:p-5 space-y-4">
        <h3 className="text-sm font-semibold flex items-center gap-2">
          <EyeOff className="w-4 h-4 text-magenta-400" /> שכבה 3: הרעלת Checksum
        </h3>
        <div className="rounded-lg bg-background border p-4 space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <p className="text-[10px] font-mono text-muted-foreground">CRC32 מקורי:</p>
              <p className="font-mono text-sm text-foreground tracking-wider">{(() => {
                let crc = 0xFFFFFFFF;
                for (let i = 0; i < rawBytes.length; i++) {
                  crc ^= rawBytes[i];
                  for (let j = 0; j < 8; j++) crc = (crc >>> 1) ^ (crc & 1 ? 0xEDB88320 : 0);
                }
                return ((crc ^ 0xFFFFFFFF) >>> 0).toString(16).padStart(8, '0');
              })()}</p>
            </div>
            <div className="space-y-1">
              <p className="text-[10px] font-mono text-destructive">CRC32 "מורעל":</p>
              <p className="font-mono text-sm text-destructive tracking-wider">{(() => {
                let crc = 0xFFFFFFFF;
                for (let i = 0; i < rawBytes.length; i++) {
                  crc ^= rawBytes[i];
                  for (let j = 0; j < 8; j++) crc = (crc >>> 1) ^ (crc & 1 ? 0xEDB88320 : 0);
                }
                const original = ((crc ^ 0xFFFFFFFF) >>> 0).toString(16).padStart(8, '0');
                // Poison it
                const seed = fnv1a(password + ':checksum');
                const rng = xoshiro128ss(seed);
                let poisoned = '';
                for (let i = 0; i < original.length; i++) {
                  const c = original.charCodeAt(i);
                  poisoned += String.fromCharCode(c ^ (rng() & 0x7F));
                }
                return [...poisoned].map(c => c.charCodeAt(0).toString(16).padStart(2, '0')).join('').slice(0, 8);
              })()}</p>
            </div>
          </div>
          <div className="rounded-lg bg-destructive/5 border border-destructive/20 p-3">
            <p className="text-xs text-center text-muted-foreground">
              ⚠️ תוקף שמנסה סיסמה שגויה מקבל checksum שגוי + נתונים שגויים — <strong className="text-destructive">אין שום דרך לדעת אם הסיסמה נכונה!</strong>
            </p>
          </div>
        </div>
      </div>

      {/* ── BOTTOM LINE ── */}
      <div className="rounded-xl border border-primary/20 bg-primary/5 p-5 text-center space-y-3">
        <h3 className="font-bold text-lg">🔐 שורה תחתונה</h3>
        <p className="text-sm text-muted-foreground max-w-lg mx-auto">
          עם סיסמה באורך <strong className="text-primary font-mono">{password.length}+</strong> תווים, 
          שלוש שכבות ההצפנה יחד הופכות את הפריצה ל<strong className={levelColors[ft.level]}>{ft.level === 'impossible' ? 'בלתי אפשרית מבחינה פיזית' : ft.level === 'hard' ? 'קשה מאוד' : 'מאתגרת'}</strong>.
          אפילו מחשב-על שמנסה מיליארד סיסמאות בשנייה לא יכול — כי הוא עיוור (שכבה 3).
        </p>
      </div>
    </div>
  );
}