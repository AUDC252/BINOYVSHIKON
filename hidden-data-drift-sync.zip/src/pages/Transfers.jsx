import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Trash2, History, Upload, ScanLine, QrCode } from 'lucide-react';
import { Link } from 'react-router-dom';
import { getAllSessions, deleteSession, loadTransfers, formatBytes } from '@/lib/qr-engine';
import { toast } from 'sonner';

export default function Transfers() {
  const [sessions, setSessions] = useState([]);

  useEffect(() => {
    loadTransfers();
    setSessions(getAllSessions());
  }, []);

  const handleDelete = (id) => {
    deleteSession(id);
    setSessions(getAllSessions());
    toast.success('Transfer session deleted');
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      <div>
        <h1 className="text-xl sm:text-2xl font-bold">Transfer History</h1>
        <p className="text-xs sm:text-sm text-muted-foreground mt-1">
          View and manage saved transfer sessions
        </p>
      </div>

      {sessions.length === 0 ? (
        <div className="rounded-xl border-2 border-dashed border-border flex items-center justify-center min-h-[200px] sm:min-h-[300px]">
          <div className="text-center text-muted-foreground p-6">
            <History className="w-8 h-8 sm:w-10 sm:h-10 mx-auto mb-3 opacity-30" />
            <p className="text-sm font-medium">No transfer sessions yet</p>
            <p className="text-xs mt-1 mb-4">Encode or decode a file to create a session</p>
            <div className="flex gap-2 justify-center">
              <Link to="/encode">
                <Button size="sm" className="gap-1.5"><Upload className="w-3.5 h-3.5" /> Encode</Button>
              </Link>
              <Link to="/decode">
                <Button size="sm" variant="outline" className="gap-1.5"><ScanLine className="w-3.5 h-3.5" /> Decode</Button>
              </Link>
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-2 sm:space-y-3">
          {sessions.map((s) => (
            <Card key={s.id}>
              <CardContent className="p-3 sm:p-4">
                <div className="flex items-start gap-3">
                  <div className="flex-1 min-w-0 space-y-1.5">
                    <div className="flex items-center gap-2 flex-wrap">
                      <Badge variant={s.type === 'encode' ? 'default' : 'secondary'} className="text-[10px]">
                        {s.type === 'encode' ? (
                          <><QrCode className="w-3 h-3 mr-1" />Encode</>
                        ) : (
                          <><ScanLine className="w-3 h-3 mr-1" />Decode</>
                        )}
                      </Badge>
                      <span className="font-mono text-[10px] sm:text-xs text-muted-foreground">{s.id}</span>
                    </div>
                    <p className="text-sm font-medium truncate">{s.fileName}</p>
                    <div className="flex flex-wrap gap-x-3 gap-y-0.5 text-xs text-muted-foreground">
                      <span>{formatBytes(s.fileSize)}</span>
                      <span className="font-mono">{s.totalChunks} chunks</span>
                      <span>{new Date(s.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0" onClick={() => handleDelete(s.id)}>
                    <Trash2 className="w-3.5 h-3.5 text-muted-foreground" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}