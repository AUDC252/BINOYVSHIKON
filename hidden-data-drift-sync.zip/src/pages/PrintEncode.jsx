import React, { useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Palette, QrCode, Lock } from 'lucide-react';
import FileUploader from '@/components/encode/FileUploader';
import ColorGridEncoder from '@/components/colorgrid/ColorGridEncoder';
import PasswordInput from '@/components/encode/PasswordInput';
import { getCapacityInfo } from '@/lib/colorgrid';
import { formatBytes } from '@/lib/qr-engine';

export default function PrintEncode() {
  const [file, setFile] = useState(null);
  const [password, setPassword] = useState('');
  const capacity = getCapacityInfo();

  return (
    <div className="space-y-4 sm:space-y-6">
      <div>
        <h1 className="text-xl sm:text-2xl font-bold flex items-center gap-2">
          <Palette className="w-5 h-5 sm:w-6 sm:h-6 text-primary" />
          Color Grid Encode
        </h1>
        <p className="text-xs sm:text-sm text-muted-foreground mt-1">
          Encode files into high-density color pages — print or save as images.
          Up to <strong className="text-foreground">{formatBytes(capacity.netCapacityPerPage)}</strong> per page.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-xs">
        <div className="rounded-lg border bg-card p-3 flex items-center gap-2">
          <div className="w-8 h-8 rounded bg-primary/10 flex items-center justify-center">
            <Palette className="w-4 h-4 text-primary" />
          </div>
          <div>
            <p className="font-medium">8-Color Encoding</p>
            <p className="text-muted-foreground">3 bits per pixel block</p>
          </div>
        </div>
        <div className="rounded-lg border bg-card p-3 flex items-center gap-2">
          <div className="w-8 h-8 rounded bg-accent/10 flex items-center justify-center">
            <QrCode className="w-4 h-4 text-accent" />
          </div>
          <div>
            <p className="font-medium">Error Correction</p>
            <p className="text-muted-foreground">Reed-Solomon per row</p>
          </div>
        </div>
        <div className="rounded-lg border bg-card p-3 flex items-center gap-2">
          <div className="w-8 h-8 rounded bg-destructive/10 flex items-center justify-center">
            <span className="text-sm">📄</span>
          </div>
          <div>
            <p className="font-medium">Print Ready</p>
            <p className="text-muted-foreground">A4 optimized layout</p>
          </div>
        </div>
      </div>

      <FileUploader file={file} onFileSelect={setFile} onClear={() => setFile(null)} />

      {file && (
        <div className="space-y-4">
          <div className="rounded-xl border bg-card p-4 sm:p-5">
            <h2 className="font-semibold text-sm mb-3">Encryption (Optional)</h2>
            <PasswordInput password={password} onChange={setPassword} />
          </div>
          <ColorGridEncoder file={file} password={password} />
        </div>
      )}
    </div>
  );
}